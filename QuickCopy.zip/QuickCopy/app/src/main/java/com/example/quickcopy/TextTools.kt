package com.example.quickcopy

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

object TextTools {
    private var tts: TextToSpeech? = null
    private var ready = false
    private val main = Handler(Looper.getMainLooper())

    // ---------------- نسخ ----------------
    fun copy(ctx: Context, text: String, record: Boolean = true) {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("QuickCopy", text))
        if (record) History.add(ctx, text)
        // لا نعيد التقاط ما نسخناه نحن للتو
        try {
            val ts = cm.primaryClipDescription?.timestamp ?: 0L
            ctx.getSharedPreferences("qc", Context.MODE_PRIVATE).edit().putLong("lastclip", ts).apply()
        } catch (e: Exception) {
        }
    }

    /** يلتقط نص الحافظة الحالي إن كان جديداً ومسموحاً (قيود أندرويد 10+ قد تمنعه في الخلفية). */
    fun captureClipboard(ctx: Context): Boolean {
        val p = ctx.getSharedPreferences("qc", Context.MODE_PRIVATE)
        if (!p.getBoolean("autocap", true)) return false
        return try {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val d = cm.primaryClipDescription ?: return false
            val ts = d.timestamp
            if (ts <= p.getLong("lastclip", 0L)) return false
            if (d.extras?.getBoolean("android.content.extra.IS_SENSITIVE", false) == true) {
                p.edit().putLong("lastclip", ts).apply()
                return false
            }
            val clip = cm.primaryClip ?: return false
            if (clip.itemCount == 0) return false
            val t = clip.getItemAt(0).coerceToText(ctx).toString().trim()
            p.edit().putLong("lastclip", ts).apply()
            if (t.isEmpty()) false else History.add(ctx, t)
        } catch (e: Exception) {
            false
        }
    }

    /** نص الحافظة الحالي إن كان متاحاً (التطبيق في المقدمة). */
    fun clipText(ctx: Context): String? {
        return try {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip ?: return null
            if (clip.itemCount == 0) return null
            val t = clip.getItemAt(0).coerceToText(ctx).toString()
            if (t.isBlank()) null else t
        } catch (e: Exception) {
            null
        }
    }

    // ---------------- مشاركة وترجمة ----------------
    fun share(ctx: Context, text: String): Boolean {
        if (text.isBlank()) return false
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        return try {
            ctx.startActivity(Intent.createChooser(i, S.t(ctx, "share_title")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            true
        } catch (e: Exception) {
            false
        }
    }

    /** يفتح Google Translate بالنص، وإلا يعرض قائمة المشاركة. */
    fun translate(ctx: Context, text: String): Boolean {
        if (text.isBlank()) return false
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
            setPackage("com.google.android.apps.translate")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            ctx.startActivity(send)
            return true
        } catch (e: Exception) {
        }
        return share(ctx, text)
    }

    fun openTtsSettings(ctx: Context) {
        val list = listOf(Intent("com.android.settings.TTS_SETTINGS"), Intent(Settings.ACTION_SETTINGS))
        for (i in list) {
            try {
                ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return
            } catch (e: Exception) {
            }
        }
    }

    // ---------------- قراءة صوتية ----------------
    fun detectLang(text: String): String {
        var ar = 0
        var en = 0
        for (c in text) {
            if (c in '\u0600'..'\u06FF') ar++
            else if (c in 'A'..'Z' || c in 'a'..'z') en++
        }
        return if (ar >= en && ar > 0) "ar" else if (en > 0) "en" else "ar"
    }

    private fun chunks(text: String, max: Int): List<String> {
        val out = ArrayList<String>()
        var rest = text.trim()
        while (rest.length > max) {
            var cut = rest.lastIndexOf('\n', max)
            if (cut < max / 2) cut = rest.lastIndexOf(' ', max)
            if (cut < max / 2) cut = max
            out.add(rest.substring(0, cut).trim())
            rest = rest.substring(cut).trim()
        }
        if (rest.isNotEmpty()) out.add(rest)
        return out
    }

    /**
     * onEvent: start / done / stopped / missing_data / no_engine / preparing / error
     * (تُستدعى على الخيط الرئيسي)
     */
    fun speak(ctx: Context, text: String, lang: String, onEvent: (String) -> Unit) {
        if (text.isBlank()) return
        val app = ctx.applicationContext

        fun go() {
            val t = tts ?: return
            val loc = if (lang == "ar") Locale("ar") else Locale.ENGLISH
            val r = t.setLanguage(loc)
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                onEvent("missing_data")
                return
            }
            val parts = chunks(text, (TextToSpeech.getMaxSpeechInputLength() - 100).coerceAtLeast(500))
            val lastId = "qc_" + (parts.size - 1)
            t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    if (utteranceId == "qc_0") main.post { onEvent("start") }
                }

                override fun onDone(utteranceId: String?) {
                    if (utteranceId == lastId) main.post { onEvent("done") }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    main.post { onEvent("error") }
                }

                override fun onStop(utteranceId: String?, interrupted: Boolean) {
                    if (interrupted) main.post { onEvent("stopped") }
                }
            })
            t.stop()
            for ((i, part) in parts.withIndex()) {
                t.speak(part, if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, "qc_$i")
            }
        }

        if (tts == null) {
            ready = false
            tts = TextToSpeech(app) { st ->
                if (st == TextToSpeech.SUCCESS) {
                    ready = true
                    main.post { go() }
                } else {
                    tts?.shutdown()
                    tts = null
                    ready = false
                    main.post { onEvent("no_engine") }
                }
            }
            return
        }
        if (!ready) {
            onEvent("preparing")
            return
        }
        go()
    }

    fun stop() {
        tts?.stop()
    }

    fun isSpeaking(): Boolean = try { tts?.isSpeaking == true } catch (e: Exception) { false }

    fun release() {
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (e: Exception) {
        }
        tts = null
        ready = false
    }
}
