package com.example.quickcopy

import android.content.Context
import android.content.res.Configuration
import android.graphics.drawable.GradientDrawable

class Pal(val dark: Boolean) {
    private fun c(v: Long): Int = v.toInt()
    val bg = if (dark) c(0xFF0B1220) else c(0xFFF3F6FC)
    val nav = if (dark) c(0xFF0F1830) else c(0xFFFFFFFF)
    val card = if (dark) c(0xFF131D33) else c(0xFFFFFFFF)
    val card2 = if (dark) c(0xFF1B2744) else c(0xFFE8EEF9)
    val stroke = if (dark) c(0xFF22304F) else c(0xFFD7E0F0)
    val text = if (dark) c(0xFFEAF0FF) else c(0xFF0F1A33)
    val sub = if (dark) c(0xFF8FA3C7) else c(0xFF5B6B8C)
    val accent = c(0xFF2F6BFF)
    val blue = c(0xFF2F6BFF)
    val green = c(0xFF10B981)
    val purple = c(0xFF7C4DFF)
    val orange = c(0xFFF59E0B)
    val red = c(0xFFEF4444)
}

fun isDarkMode(ctx: Context): Boolean {
    val p = ctx.getSharedPreferences("qc", Context.MODE_PRIVATE).getString("theme", "system") ?: "system"
    return when (p) {
        "dark" -> true
        "light" -> false
        else -> (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }
}

fun Context.rounded(fill: Int, radiusDp: Int, stroke: Int = 0): GradientDrawable =
    GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radiusDp).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }
