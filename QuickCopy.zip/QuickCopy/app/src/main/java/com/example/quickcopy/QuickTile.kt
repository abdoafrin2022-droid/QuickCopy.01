package com.example.quickcopy

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.widget.Toast

class QuickTile : TileService() {
    override fun onStartListening() {
        qsTile?.let {
            it.state = Tile.STATE_INACTIVE
            it.updateTile()
        }
    }

    override fun onClick() {
        val s = CopyService.instance
        if (s == null) {
            Toast.makeText(this, "فعّل خدمة «نسخ سريع» من إمكانية الوصول أولاً", Toast.LENGTH_LONG).show()
        } else {
            s.openFromTile()
        }
    }
}
