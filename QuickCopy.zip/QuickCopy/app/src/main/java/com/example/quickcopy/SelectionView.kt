package com.example.quickcopy

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

class Item(val rect: Rect, val text: String, var selected: Boolean = false) {
    fun area(): Long = rect.width().toLong() * rect.height()
}

class SelectionView(
    ctx: Context,
    private val items: List<Item>,
    private val onChange: () -> Unit,
    private val onLongPress: (Item) -> Unit
) : View(ctx) {

    private val dim = Paint().apply { color = 0x1A000000 }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 3f; color = 0xFF42A5F5.toInt()
    }
    private val fillSel = Paint().apply { color = 0x6643A047 }
    private val strokeSel = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 4f; color = 0xFF2E7D32.toInt()
    }
    private val bandPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 4f; color = -1
    }

    private var band: RectF? = null
    private var sx = 0f
    private var sy = 0f
    private var vx = 0f
    private var vy = 0f
    private var longHit = false
    var regionMode = false
    var showBoxes = true
    var onRegion: ((Rect) -> Unit)? = null
    private val off = IntArray(2)

    private val longRunnable = Runnable {
        if (regionMode) return@Runnable
        longHit = true
        findAt(sx.toInt(), sy.toInt())?.let(onLongPress)
    }

    override fun onDraw(c: Canvas) {
        getLocationOnScreen(off)
        if (showBoxes) c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dim)
        c.save()
        c.translate(-off[0].toFloat(), -off[1].toFloat())
        // الأكبر أولاً حتى تبقى الصغيرة ظاهرة فوقها
        for (i in items.sortedByDescending { it.area() }) {
            if (i.selected) {
                c.drawRect(i.rect, fillSel)
                c.drawRect(i.rect, strokeSel)
            } else if (showBoxes) {
                c.drawRect(i.rect, stroke)
            }
        }
        c.restore()
        band?.let { c.drawRect(it, bandPaint) }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                sx = e.rawX; sy = e.rawY; vx = e.x; vy = e.y; band = null; longHit = false
                postDelayed(longRunnable, ViewConfiguration.getLongPressTimeout().toLong())
            }
            MotionEvent.ACTION_MOVE -> {
                if (longHit) return true
                val d = context.dp(12)
                if (band != null || abs(e.rawX - sx) > d || abs(e.rawY - sy) > d) {
                    removeCallbacks(longRunnable)
                    band = RectF(min(vx, e.x), min(vy, e.y), max(vx, e.x), max(vy, e.y))
                }
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                removeCallbacks(longRunnable)
                if (longHit) { longHit = false; return true }
                if (band == null) {
                    if (!regionMode) tap(e.rawX.toInt(), e.rawY.toInt())
                } else {
                    val r = Rect(
                        min(sx, e.rawX).toInt(), min(sy, e.rawY).toInt(),
                        max(sx, e.rawX).toInt(), max(sy, e.rawY).toInt()
                    )
                    if (regionMode) {
                        regionMode = false
                        band = null
                        invalidate()
                        onRegion?.invoke(r)
                        return true
                    } else {
                        items.filter { Rect.intersects(it.rect, r) }.forEach { it.selected = true }
                    }
                    band = null
                }
                invalidate()
                onChange()
            }
            MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(longRunnable); band = null; invalidate()
            }
        }
        return true
    }

    private fun findAt(x: Int, y: Int): Item? =
        items.filter { it.rect.contains(x, y) }.minByOrNull { it.area() }

    private fun tap(x: Int, y: Int) {
        findAt(x, y)?.let { it.selected = !it.selected }
    }
}
