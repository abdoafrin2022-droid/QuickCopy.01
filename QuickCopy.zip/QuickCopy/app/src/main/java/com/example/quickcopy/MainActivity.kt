package com.example.quickcopy

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private var historyBox: LinearLayout? = null

    private fun refreshHistory() {
        val box = historyBox ?: return
        box.removeAllViews()
        val list = History.load(this)
        val title = TextView(this).apply {
            text = "آخر ما نسخته"; textSize = 20f; setTextColor(Color.BLACK)
            setPadding(0, dp(24), 0, dp(8))
        }
        box.addView(title)
        if (list.isEmpty()) {
            box.addView(TextView(this).apply { text = "لا يوجد شيء بعد"; setTextColor(Color.DKGRAY) })
            return
        }
        for (t in list) {
            box.addView(Button(this).apply {
                text = t.replace('\n', ' ').take(70)
                isAllCaps = false
                setOnClickListener {
                    val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("QuickCopy", t))
                    Toast.makeText(this@MainActivity, "تم النسخ ✓", Toast.LENGTH_SHORT).show()
                }
            })
        }
        box.addView(Button(this).apply {
            text = "مسح السجل"
            setOnClickListener { History.clear(this@MainActivity); refreshHistory() }
        })
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("qc", MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(20), dp(40), dp(20), dp(20))
        }
        fun text(s: String, size: Float = 16f, bold: Boolean = false) = TextView(this).apply {
            this.text = s; textSize = size; setTextColor(Color.BLACK)
            textDirection = View.TEXT_DIRECTION_RTL
            gravity = Gravity.START
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(8), 0, dp(8))
        }
        fun button(s: String, onClick: () -> Unit) = Button(this).apply {
            this.text = s; setOnClickListener { onClick() }
        }

        root.addView(text("نسخ سريع", 26f, true))
        root.addView(text(
            "طريقة الاستخدام:\n" +
            "• اضغط الزر العائم 📋 فتظهر مربعات حول النصوص.\n" +
            "• اضغط على مربع لتحديده (أو اسحب لتحديد عدة مربعات) ثم «نسخ».\n" +
            "• لنسخ جملة معينة فقط: اضغط مطولاً على المربع، فتظهر بطاقة بالنص، حدد الجملة بالضغط المطول والسحب ثم «نسخ».\n" +
            "• لقراءة نص مكتوب داخل صورة: زر «قراءة صورة»، ثم ارسم مربعاً بإصبعك حول النص، فيظهر النص المقروء وتقدر تنسخه.\n" +
            "• أزرار الشريط: نسخ، الكل، 🖼 قراءة صورة، ▦ إظهار/إخفاء المربعات، ⌄ تصغير الشريط لتصير الشاشة كلها متاحة (ويبقى زر نسخ صغير)، ✕ إغلاق.\n" +
            "• في بطاقة الجملة: 🔊 قراءة النص بالصوت، 🌐 ترجمة (Google Translate)، ↗ مشاركة.\n" +
            "• كل ما تنسخه يُحفظ في «آخر ما نسخته» أسفل هذه الصفحة (يمكن مسحه).\n" +
            "• لإخفاء الزر العائم مؤقتاً: اسحبه إلى علامة ✕ في أسفل الشاشة، ولإظهاره اضغط زر الزر العائم هنا."
        ))

        lateinit var toggle: Button
        fun toggleLabel() =
            if (prefs.getBoolean("bubble", true)) "الزر العائم: ظاهر ✓ (اضغط لإخفائه)"
            else "الزر العائم: مخفي (اضغط لإظهاره)"
        toggle = button(toggleLabel()) {
            val now = !prefs.getBoolean("bubble", true)
            prefs.edit().putBoolean("bubble", now).apply()
            val s = CopyService.instance
            if (s == null) Toast.makeText(this, "فعّل الخدمة من إمكانية الوصول أولاً", Toast.LENGTH_SHORT).show()
            else s.setBubbleEnabled(now)
            toggle.text = toggleLabel()
        }
        root.addView(toggle)

        lateinit var boxesBtn: Button
        fun boxesLabel() =
            if (prefs.getBoolean("boxes", true)) "مربعات النصوص: ظاهرة ✓ (اضغط لإخفائها)"
            else "مربعات النصوص: مخفية (اضغط لإظهارها)"
        boxesBtn = button(boxesLabel()) {
            prefs.edit().putBoolean("boxes", !prefs.getBoolean("boxes", true)).apply()
            boxesBtn.text = boxesLabel()
        }
        root.addView(boxesBtn)

        root.addView(button("فتح إعدادات إمكانية الوصول") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(button("معلومات التطبيق") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })
        val status = text(if (OcrEngine.hasData(this)) "لغات OCR جاهزة ✓" else "لغات OCR غير محمّلة بعد")
        root.addView(button("تحميل لغات قراءة الصور (عربي + إنجليزي، ~30MB)") {
            val h = Handler(Looper.getMainLooper())
            Thread {
                val ok = OcrEngine.ensureData(this) { s -> h.post { status.text = s } }
                h.post { status.text = if (ok) "لغات OCR جاهزة ✓" else "فشل التحميل — تأكد من الإنترنت" }
            }.start()
        })
        root.addView(status)
        historyBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(historyBox)
        refreshHistory()
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refreshHistory()
    }
}
