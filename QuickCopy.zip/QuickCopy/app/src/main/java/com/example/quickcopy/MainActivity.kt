package com.example.quickcopy

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var pal: Pal
    private var rtl = false
    private lateinit var content: FrameLayout
    private var navItems: List<Pair<TextView, TextView>> = emptyList()
    private var tab = 0
    private val reqPick = 1001
    private val prefs by lazy { getSharedPreferences("qc", MODE_PRIVATE) }

    private fun t(k: String) = S.t(this, k)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ------------------------------------------------------------------ مساعدات واجهة
    private fun tv(text: String, size: Float = 15f, color: Int = pal.text, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            textDirection = View.TEXT_DIRECTION_ANY_RTL
        }

    private fun lp(
        w: Int = -1, h: Int = -2, weight: Float = 0f,
        mt: Int = 0, mb: Int = 0, ms: Int = 0, me: Int = 0
    ): LinearLayout.LayoutParams = LinearLayout.LayoutParams(w, h, weight).apply {
        topMargin = mt; bottomMargin = mb; marginStart = ms; marginEnd = me
    }

    private fun vbox(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun hbox(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun pill(label: String, fill: Int, textColor: Int, onClick: () -> Unit): TextView =
        tv(label, 14f, textColor, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(11), dp(12), dp(11))
            background = rounded(fill, 14)
            isClickable = true
            setOnClickListener { onClick() }
        }

    private fun makeDialog(build: (LinearLayout, Dialog) -> Unit): Dialog {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val box = vbox().apply {
            background = rounded(pal.card, 22, pal.stroke)
            setPadding(dp(18), dp(18), dp(18), dp(14))
            layoutDirection = if (rtl) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
        }
        build(box, d)
        d.setContentView(box)
        d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        d.window?.setLayout((resources.displayMetrics.widthPixels * 0.9).toInt(), WindowManager.LayoutParams.WRAP_CONTENT)
        d.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        d.show()
        return d
    }

    private fun confirm(title: String, msg: String, yes: String, onYes: () -> Unit) {
        makeDialog { box, d ->
            box.addView(tv(title, 18f, pal.text, true))
            box.addView(tv(msg, 14f, pal.sub), lp(mt = dp(8)))
            val row = hbox()
            row.addView(pill(t("cancel"), pal.card2, pal.text) { d.dismiss() }, lp(0, -2, 1f, me = dp(6)))
            row.addView(pill(yes, pal.red, Color.WHITE) { d.dismiss(); onYes() }, lp(0, -2, 1f, ms = dp(6)))
            box.addView(row, lp(mt = dp(16)))
        }
    }

    private fun textDialog(title: String, initial: String, withCopy: Boolean, onSave: (String, Boolean) -> Unit) {
        makeDialog { box, d ->
            box.addView(tv(title, 18f, pal.text, true))
            val et = EditText(this).apply {
                setText(initial)
                hint = t("type_here")
                setHintTextColor(pal.sub)
                setTextColor(pal.text)
                textSize = 15f
                minLines = 4
                maxLines = 10
                gravity = Gravity.TOP or Gravity.START
                background = rounded(pal.card2, 14)
                setPadding(dp(12), dp(10), dp(12), dp(10))
                textDirection = View.TEXT_DIRECTION_ANY_RTL
            }
            box.addView(et, lp(mt = dp(12)))
            val row = hbox()
            row.addView(pill(t("cancel"), pal.card2, pal.text) { d.dismiss() }, lp(0, -2, 1f, me = dp(4)))
            row.addView(pill(t("save"), pal.accent, Color.WHITE) {
                val x = et.text.toString().trim()
                if (x.isEmpty()) toast(t("empty_text")) else { d.dismiss(); onSave(x, false) }
            }, lp(0, -2, 1f, ms = dp(4), me = dp(4)))
            if (withCopy) {
                row.addView(pill(t("save_copy"), pal.green, Color.WHITE) {
                    val x = et.text.toString().trim()
                    if (x.isEmpty()) toast(t("empty_text")) else { d.dismiss(); onSave(x, true) }
                }, lp(0, -2, 1f, ms = dp(4)))
            }
            box.addView(row, lp(mt = dp(14)))
            et.requestFocus()
        }
    }

    // ------------------------------------------------------------------ دورة الحياة
    override fun onCreate(savedInstanceState: Bundle?) {
        val dark = isDarkMode(this)
        setTheme(if (dark) android.R.style.Theme_Material_NoActionBar else android.R.style.Theme_Material_Light_NoActionBar)
        super.onCreate(savedInstanceState)
        pal = Pal(dark)
        rtl = S.isRtl(this)
        tab = savedInstanceState?.getInt("tab") ?: 0

        val root = vbox().apply {
            setBackgroundColor(pal.bg)
            layoutDirection = if (rtl) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
        }
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(buildNav(), LinearLayout.LayoutParams(-1, -2))
        setContentView(root)

        window.statusBarColor = pal.bg
        window.navigationBarColor = pal.nav
        val mask = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
        window.insetsController?.setSystemBarsAppearance(if (dark) 0 else mask, mask)

        show(tab)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("tab", tab)
    }

    override fun onResume() {
        super.onResume()
        // التقاط ما نُسخ حديثاً (مسموح لأن التطبيق في المقدمة)
        if (TextTools.captureClipboard(this) && tab != 3) show(tab)
    }

    override fun onDestroy() {
        TextTools.release()
        super.onDestroy()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode == reqPick && resultCode == RESULT_OK && uri != null) {
            startActivity(
                Intent(this, ImageOcrActivity::class.java)
                    .setData(uri)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        }
    }

    // ------------------------------------------------------------------ التنقل
    private fun buildNav(): View {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(pal.nav)
            setPadding(0, dp(4), 0, dp(4))
        }
        val icons = listOf("🏠", "⭐", "🕘", "⚙️")
        val keys = listOf("home", "favorites", "history", "settings")
        val list = ArrayList<Pair<TextView, TextView>>()
        for (i in 0..3) {
            val item = vbox().apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(6), 0, dp(6))
                isClickable = true
                setOnClickListener { show(i) }
            }
            val ic = tv(icons[i], 20f).apply { gravity = Gravity.CENTER }
            val lb = tv(t(keys[i]), 11f, pal.sub).apply { gravity = Gravity.CENTER }
            item.addView(ic, lp(-2, -2))
            item.addView(lb, lp(-2, -2))
            bar.addView(item, LinearLayout.LayoutParams(0, -2, 1f))
            list.add(Pair(ic, lb))
        }
        navItems = list
        return bar
    }

    private fun show(i: Int) {
        tab = i
        content.removeAllViews()
        val v = when (i) {
            0 -> homeView()
            1 -> listScreen(true)
            2 -> listScreen(false)
            else -> settingsView()
        }
        content.addView(v, FrameLayout.LayoutParams(-1, -1))
        for ((idx, p) in navItems.withIndex()) {
            val sel = idx == i
            p.second.setTextColor(if (sel) pal.accent else pal.sub)
            p.second.typeface = if (sel) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            p.first.alpha = if (sel) 1f else 0.55f
        }
    }

    // ------------------------------------------------------------------ بيانات
    private fun currentText(): String? = TextTools.clipText(this) ?: History.all(this).firstOrNull()?.text

    private fun ago(ts: Long): String {
        val m = (System.currentTimeMillis() - ts) / 60000
        val ar = S.lang(this) == "ar"
        return when {
            m < 1 -> t("now")
            m < 60 -> if (ar) "منذ $m د" else "$m min ago"
            m < 1440 -> { val h = m / 60; if (ar) "منذ $h ساعة" else "$h h ago" }
            else -> { val d = m / 1440; if (ar) "منذ $d يوم" else "$d d ago" }
        }
    }

    // ------------------------------------------------------------------ مكونات القائمة
    private fun searchField(onChange: (String) -> Unit): EditText = EditText(this).apply {
        hint = "🔍  " + t("search_hint")
        setHintTextColor(pal.sub)
        setTextColor(pal.text)
        textSize = 15f
        setSingleLine(true)
        background = rounded(pal.card, 16, pal.stroke)
        setPadding(dp(16), dp(12), dp(16), dp(12))
        textDirection = View.TEXT_DIRECTION_ANY_RTL
        addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { onChange(s?.toString() ?: "") }
        })
    }

    private fun fillList(box: LinearLayout, getQ: () -> String, favOnly: Boolean, limit: Int) {
        box.removeAllViews()
        val q = getQ().trim()
        var list = History.all(this)
        if (favOnly) list = list.filter { it.fav }
        if (q.isNotEmpty()) list = list.filter { it.text.contains(q, ignoreCase = true) }
        if (limit > 0) list = list.take(limit)
        if (list.isEmpty()) {
            val msg = when {
                q.isNotEmpty() -> t("no_results")
                favOnly -> t("empty_favs")
                else -> t("empty_history")
            }
            box.addView(tv(msg, 14f, pal.sub).apply {
                gravity = Gravity.CENTER
                setPadding(dp(8), dp(28), dp(8), dp(28))
            }, lp())
            return
        }
        for (e in list) {
            box.addView(entryCard(e) { fillList(box, getQ, favOnly, limit) }, lp(mb = dp(8)))
        }
    }

    private fun entryCard(e: History.Entry, refresh: () -> Unit): View {
        val card = hbox().apply {
            setPadding(dp(12), dp(12), dp(8), dp(12))
            background = rounded(pal.card, 16, pal.stroke)
            isClickable = true
        }
        val icon = tv(if (e.fav) "⭐" else "📋", 18f).apply { gravity = Gravity.CENTER }
        card.addView(icon, lp(dp(36), dp(36)))
        val col = vbox()
        col.addView(tv(e.text, 15f).apply {
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.START
        }, lp())
        col.addView(tv(ago(e.ts), 11f, pal.sub), lp(mt = dp(3)))
        card.addView(col, lp(0, -2, 1f, ms = dp(8), me = dp(4)))
        val more = tv("⋮", 20f, pal.sub, true).apply {
            gravity = Gravity.CENTER
            isClickable = true
            setOnClickListener { showMenu(e, refresh) }
        }
        card.addView(more, lp(dp(36), dp(40)))
        card.setOnClickListener {
            TextTools.copy(this, e.text, record = false)
            toast(t("copied"))
        }
        card.setOnLongClickListener { showMenu(e, refresh); true }
        return card
    }

    private fun showMenu(e: History.Entry, refresh: () -> Unit) {
        makeDialog { box, d ->
            box.addView(tv(e.text, 13f, pal.sub).apply {
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
                setPadding(dp(4), 0, dp(4), dp(8))
            }, lp())
            fun item(icon: String, label: String, color: Int = pal.text, act: () -> Unit) {
                val row = hbox().apply {
                    setPadding(dp(10), dp(13), dp(10), dp(13))
                    isClickable = true
                    setOnClickListener { d.dismiss(); act() }
                }
                row.addView(tv(icon, 18f, color).apply { gravity = Gravity.CENTER }, lp(dp(32), -2))
                row.addView(tv(label, 15f, color), lp(0, -2, 1f, ms = dp(8)))
                box.addView(row, lp())
            }
            item("📋", t("menu_copy")) { TextTools.copy(this, e.text, record = false); toast(t("copied")) }
            item("🔊", t("menu_read")) { showPlayer(e.text) }
            item("🌐", t("menu_translate")) { if (!TextTools.translate(this, e.text)) toast(t("tr_fail")) }
            item("↗", t("menu_share")) { if (!TextTools.share(this, e.text)) toast(t("share_fail")) }
            item("⭐", if (e.fav) t("menu_fav_remove") else t("menu_fav_add")) {
                History.toggleFav(this, e.id); refresh()
            }
            item("✏️", t("menu_edit")) {
                textDialog(t("edit_title"), e.text, false) { x, _ ->
                    if (History.update(this, e.id, x)) toast(t("updated"))
                    refresh()
                }
            }
            item("🗑", t("menu_delete"), pal.red) {
                History.delete(this, e.id); toast(t("deleted")); refresh()
            }
        }
    }

    // ------------------------------------------------------------------ مشغّل الصوت
    private fun showPlayer(text: String) {
        var lang = when (prefs.getString("ttslang", "auto")) {
            "ar" -> "ar"
            "en" -> "en"
            else -> TextTools.detectLang(text)
        }
        val dlg = makeDialog { box, d ->
            box.addView(tv(t("player_title"), 18f, pal.text, true))
            val prev = tv(text, 15f).apply {
                setPadding(dp(12), dp(10), dp(12), dp(10))
                background = rounded(pal.card2, 14)
            }
            val sc = ScrollView(this).apply { addView(prev) }
            box.addView(sc, lp(-1, (resources.displayMetrics.heightPixels * 0.22).toInt(), mt = dp(10)))

            val chAr = pill(t("lang_ar"), pal.card2, pal.text) {}
            val chEn = pill(t("lang_en"), pal.card2, pal.text) {}
            fun paintChips() {
                chAr.background = rounded(if (lang == "ar") pal.accent else pal.card2, 14)
                chAr.setTextColor(if (lang == "ar") Color.WHITE else pal.text)
                chEn.background = rounded(if (lang == "en") pal.accent else pal.card2, 14)
                chEn.setTextColor(if (lang == "en") Color.WHITE else pal.text)
            }
            chAr.setOnClickListener { TextTools.stop(); lang = "ar"; paintChips() }
            chEn.setOnClickListener { TextTools.stop(); lang = "en"; paintChips() }
            paintChips()
            val chips = hbox()
            chips.addView(chAr, lp(0, -2, 1f, me = dp(4)))
            chips.addView(chEn, lp(0, -2, 1f, ms = dp(4)))
            box.addView(chips, lp(mt = dp(12)))

            val status = tv("", 13f, pal.sub).apply { gravity = Gravity.START }
            val help = pill(t("open_tts_settings"), pal.card2, pal.text) { TextTools.openTtsSettings(this) }
            help.visibility = View.GONE

            val play = pill(t("play"), pal.accent, Color.WHITE) {
                TextTools.speak(this, text, lang) { ev ->
                    when (ev) {
                        "start" -> status.text = t("tts_playing")
                        "done" -> status.text = t("tts_done")
                        "stopped" -> status.text = t("tts_stopped")
                        "missing_data" -> { status.text = t("tts_missing"); help.visibility = View.VISIBLE }
                        "no_engine" -> status.text = t("tts_noengine")
                        "preparing" -> status.text = t("tts_preparing")
                        else -> status.text = t("tts_error")
                    }
                }
            }
            val stop = pill(t("stop"), pal.card2, pal.text) {
                TextTools.stop(); status.text = t("tts_stopped")
            }
            val ctl = hbox()
            ctl.addView(play, lp(0, -2, 1f, me = dp(4)))
            ctl.addView(stop, lp(0, -2, 1f, ms = dp(4)))
            box.addView(ctl, lp(mt = dp(12)))
            box.addView(status, lp(mt = dp(10)))
            box.addView(help, lp(mt = dp(8)))
            box.addView(pill(t("cancel"), pal.card, pal.sub) { d.dismiss() }, lp(mt = dp(6)))
        }
        dlg.setOnDismissListener { TextTools.stop() }
    }

    // ------------------------------------------------------------------ الشاشة الرئيسية
    private fun tile(icon: String, title: String, sub: String, color: Int, onClick: () -> Unit): View {
        val b = vbox().apply {
            setPadding(dp(14), dp(12), dp(14), dp(12))
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(color, 18)
            isClickable = true
            setOnClickListener { onClick() }
        }
        b.addView(tv(icon, 24f, Color.WHITE), lp())
        b.addView(tv(title, 15f, Color.WHITE, true), lp(mt = dp(6)))
        b.addView(tv(sub, 11f, 0xCCFFFFFF.toInt()), lp(mt = dp(2)))
        return b
    }

    private fun smallTile(icon: String, label: String, onClick: () -> Unit): View {
        val b = vbox().apply {
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(12), dp(8), dp(12))
            background = rounded(pal.card, 16, pal.stroke)
            isClickable = true
            setOnClickListener { onClick() }
        }
        b.addView(tv(icon, 20f).apply { gravity = Gravity.CENTER }, lp())
        b.addView(tv(label, 12f, pal.text).apply { gravity = Gravity.CENTER }, lp(mt = dp(4)))
        return b
    }

    private fun startScreenCopy() {
        val s = CopyService.instance
        if (s == null) {
            toast(t("enable_service_first"))
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }
        moveTaskToBack(true)
        s.openLater()
    }

    private fun homeView(): View {
        val sc = ScrollView(this)
        val col = vbox().apply { setPadding(dp(16), dp(14), dp(16), dp(16)) }
        sc.addView(col)

        // الرأس
        val header = hbox()
        header.addView(tv("📋", 24f, Color.WHITE).apply {
            gravity = Gravity.CENTER
            background = rounded(pal.accent, 14)
        }, lp(dp(48), dp(48)))
        val titles = vbox()
        titles.addView(tv("QuickCopy", 22f, pal.text, true), lp())
        titles.addView(tv(t("tagline"), 12f, pal.sub), lp())
        header.addView(titles, lp(0, -2, 1f, ms = dp(12), me = dp(8)))
        header.addView(tv("⚙️", 20f).apply {
            gravity = Gravity.CENTER
            background = rounded(pal.card, 14, pal.stroke)
            isClickable = true
            setOnClickListener { show(3) }
        }, lp(dp(44), dp(44)))
        col.addView(header, lp())

        // البحث + القائمة
        var q = ""
        val listBox = vbox()
        col.addView(searchField { x -> q = x; fillList(listBox, { q }, false, 5) }, lp(mt = dp(16)))

        // الأدوات
        val row1 = hbox()
        row1.addView(tile("📋", t("tool_screen"), t("tool_screen_sub"), pal.blue) { startScreenCopy() },
            lp(0, dp(112), 1f, me = dp(6)))
        row1.addView(tile("➕", t("tool_add"), t("tool_add_sub"), pal.green) {
            textDialog(t("add_title"), "", true) { x, copy ->
                History.add(this, x)
                if (copy) TextTools.copy(this, x, record = false)
                toast(t("saved"))
                fillList(listBox, { q }, false, 5)
            }
        }, lp(0, dp(112), 1f, ms = dp(6)))
        col.addView(row1, lp(mt = dp(14)))

        val row2 = hbox()
        row2.addView(tile("🖼", t("tool_image"), t("tool_image_sub"), pal.purple) { pickImage() },
            lp(0, dp(112), 1f, me = dp(6)))
        row2.addView(tile("📥", t("tool_clip"), t("tool_clip_sub"), pal.orange) {
            val x = TextTools.clipText(this)
            if (x == null) toast(t("clip_empty")) else {
                History.add(this, x); toast(t("saved")); fillList(listBox, { q }, false, 5)
            }
        }, lp(0, dp(112), 1f, ms = dp(6)))
        col.addView(row2, lp(mt = dp(12)))

        val row3 = hbox()
        row3.addView(smallTile("🔊", t("tool_speak")) {
            val x = currentText()
            if (x == null) toast(t("nothing_to_use")) else showPlayer(x)
        }, lp(0, -2, 1f, me = dp(4)))
        row3.addView(smallTile("🌐", t("tool_translate")) {
            val x = currentText()
            if (x == null) toast(t("nothing_to_use")) else if (!TextTools.translate(this, x)) toast(t("tr_fail"))
        }, lp(0, -2, 1f, ms = dp(4), me = dp(4)))
        row3.addView(smallTile("↗", t("tool_share")) {
            val x = currentText()
            if (x == null) toast(t("nothing_to_use")) else if (!TextTools.share(this, x)) toast(t("share_fail"))
        }, lp(0, -2, 1f, ms = dp(4)))
        col.addView(row3, lp(mt = dp(12)))

        // آخر ما نسخته
        val rh = hbox()
        rh.addView(tv(t("recent"), 17f, pal.text, true), lp(0, -2, 1f))
        rh.addView(tv(t("view_all"), 13f, pal.accent, true).apply {
            isClickable = true
            setOnClickListener { show(2) }
        }, lp(-2, -2))
        col.addView(rh, lp(mt = dp(20), mb = dp(10)))
        col.addView(listBox, lp())
        fillList(listBox, { q }, false, 5)
        return sc
    }

    private fun pickImage() {
        val i = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "image/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(Intent.createChooser(i, t("image_pick")), reqPick)
    }

    // ------------------------------------------------------------------ المفضلة / السجل
    private fun listScreen(favOnly: Boolean): View {
        val sc = ScrollView(this)
        val col = vbox().apply { setPadding(dp(16), dp(14), dp(16), dp(16)) }
        sc.addView(col)
        val all = History.all(this)
        val count = if (favOnly) all.count { it.fav } else all.size
        val head = hbox()
        head.addView(
            tv((if (favOnly) t("favorites") else t("history")) + " ($count)", 20f, pal.text, true),
            lp(0, -2, 1f)
        )
        if (!favOnly) {
            head.addView(pill(t("clear_history"), pal.card2, pal.red) {
                confirm(t("clear_confirm_title"), t("clear_confirm_msg"), t("yes_clear")) {
                    History.clear(this, true)
                    show(tab)
                }
            }, lp(-2, -2))
        }
        col.addView(head, lp())
        var q = ""
        val listBox = vbox()
        col.addView(searchField { x -> q = x; fillList(listBox, { q }, favOnly, 0) }, lp(mt = dp(14), mb = dp(12)))
        col.addView(listBox, lp())
        fillList(listBox, { q }, favOnly, 0)
        return sc
    }

    // ------------------------------------------------------------------ الإعدادات
    private fun section(col: LinearLayout, title: String): LinearLayout {
        col.addView(tv(title, 13f, pal.sub, true).apply { setPadding(dp(4), dp(18), dp(4), dp(6)) }, lp())
        val card = vbox().apply { background = rounded(pal.card, 18, pal.stroke) }
        col.addView(card, lp())
        return card
    }

    private fun divider(box: LinearLayout) {
        box.addView(View(this).apply { setBackgroundColor(pal.stroke) }, lp(-1, dp(1), ms = dp(14), me = dp(14)))
    }

    private fun choiceRow(box: LinearLayout, label: String, selected: Boolean, onClick: () -> Unit) {
        val row = hbox().apply {
            setPadding(dp(14), dp(13), dp(14), dp(13))
            isClickable = true
            setOnClickListener { onClick() }
        }
        row.addView(tv(label, 15f), lp(0, -2, 1f))
        row.addView(tv(if (selected) "●" else "○", 18f, if (selected) pal.accent else pal.sub))
        box.addView(row, lp())
    }

    private fun switchRow(box: LinearLayout, label: String, key: String, def: Boolean, after: ((Boolean) -> Unit)? = null) {
        val row = hbox().apply { setPadding(dp(14), dp(10), dp(14), dp(10)) }
        row.addView(tv(label, 15f), lp(0, -2, 1f, me = dp(8)))
        val sw = Switch(this)
        sw.isChecked = prefs.getBoolean(key, def)
        sw.setOnCheckedChangeListener { _, v ->
            prefs.edit().putBoolean(key, v).apply()
            after?.invoke(v)
        }
        row.addView(sw)
        box.addView(row, lp())
    }

    private fun seekRow(box: LinearLayout, label: String, key: String, minV: Int, maxV: Int, def: Int) {
        val wrap = vbox().apply { setPadding(dp(14), dp(10), dp(14), dp(10)) }
        val cur = prefs.getInt(key, def).coerceIn(minV, maxV)
        val title = tv("$label: $cur", 14f)
        val sb = SeekBar(this)
        sb.max = maxV - minV
        sb.progress = cur - minV
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + minV
                prefs.edit().putInt(key, v).apply()
                title.text = "$label: $v"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { CopyService.instance?.applyBubbleStyle() }
        })
        wrap.addView(title, lp())
        wrap.addView(sb, lp())
        box.addView(wrap, lp())
    }

    private fun settingsView(): View {
        val sc = ScrollView(this)
        val col = vbox().apply { setPadding(dp(16), dp(14), dp(16), dp(24)) }
        sc.addView(col)
        col.addView(tv(t("settings"), 22f, pal.text, true), lp())

        // المظهر
        val ap = section(col, t("set_appearance"))
        val theme = prefs.getString("theme", "system") ?: "system"
        for ((k, lbl) in listOf("system" to t("theme_system"), "light" to t("theme_light"), "dark" to t("theme_dark"))) {
            choiceRow(ap, lbl, theme == k) { prefs.edit().putString("theme", k).apply(); recreate() }
            divider(ap)
        }
        val lang = prefs.getString("lang", "system") ?: "system"
        val langs = listOf("system" to t("theme_system"), "ar" to "العربية", "en" to "English")
        for ((idx, p) in langs.withIndex()) {
            choiceRow(ap, (if (idx == 0) t("language") + ": " else "") + p.second, lang == p.first) {
                prefs.edit().putString("lang", p.first).apply(); recreate()
            }
            if (idx < langs.size - 1) divider(ap)
        }

        // الزر العائم
        val fl = section(col, t("set_float"))
        val on = CopyService.instance != null
        fl.addView(tv(if (on) t("service_on") else t("service_off"), 13f, if (on) pal.green else pal.orange).apply {
            setPadding(dp(14), dp(12), dp(14), dp(4))
        }, lp())
        switchRow(fl, t("float_enable"), "bubble", true) { v ->
            val s = CopyService.instance
            if (s == null) toast(t("enable_service_first")) else s.setBubbleEnabled(v)
        }
        divider(fl)
        seekRow(fl, t("float_size"), "bsize", 36, 80, 52)
        seekRow(fl, t("float_opacity"), "balpha", 30, 100, 90)
        divider(fl)
        switchRow(fl, t("float_boxes"), "boxes", true)
        val btnRow = vbox().apply { setPadding(dp(14), dp(8), dp(14), dp(14)) }
        btnRow.addView(pill(t("open_access"), pal.accent, Color.WHITE) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }, lp())
        btnRow.addView(pill(t("app_info"), pal.card2, pal.text) {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }, lp(mt = dp(8)))
        fl.addView(btnRow, lp())

        // الصوت
        val vo = section(col, t("set_voice"))
        vo.addView(tv(t("tts_default"), 13f, pal.sub).apply { setPadding(dp(14), dp(12), dp(14), dp(2)) }, lp())
        val tl = prefs.getString("ttslang", "auto") ?: "auto"
        val tOpts = listOf("auto" to t("tts_auto"), "ar" to t("lang_ar"), "en" to t("lang_en"))
        for ((idx, p) in tOpts.withIndex()) {
            choiceRow(vo, p.second, tl == p.first) { prefs.edit().putString("ttslang", p.first).apply(); show(3) }
            if (idx < tOpts.size - 1) divider(vo)
        }
        val vb = vbox().apply { setPadding(dp(14), dp(8), dp(14), dp(14)) }
        vb.addView(pill(t("open_tts_settings"), pal.card2, pal.text) { TextTools.openTtsSettings(this) }, lp())
        vo.addView(vb, lp())

        // الحافظة والسجل
        val cl = section(col, t("set_clip"))
        switchRow(cl, t("autocap"), "autocap", true)
        cl.addView(tv(t("autocap_note"), 12f, pal.sub).apply { setPadding(dp(14), 0, dp(14), dp(10)) }, lp())
        divider(cl)
        val cb = vbox().apply { setPadding(dp(14), dp(10), dp(14), dp(14)) }
        cb.addView(pill(t("clear_history"), pal.card2, pal.red) {
            confirm(t("clear_confirm_title"), t("clear_confirm_msg"), t("yes_clear")) {
                History.clear(this, true); toast(t("deleted"))
            }
        }, lp())
        cb.addView(pill(t("clear_all"), pal.card2, pal.red) {
            confirm(t("clear_all_title"), t("clear_all_msg"), t("yes_clear")) {
                History.clear(this, false); toast(t("deleted"))
            }
        }, lp(mt = dp(8)))
        cl.addView(cb, lp())

        // OCR
        val oc = section(col, t("set_ocr"))
        val ocStatus = tv(if (OcrEngine.hasData(this)) t("ocr_ready") else t("ocr_missing"), 13f, pal.sub)
            .apply { setPadding(dp(14), dp(12), dp(14), dp(4)) }
        oc.addView(ocStatus, lp())
        val ob = vbox().apply { setPadding(dp(14), dp(8), dp(14), dp(14)) }
        ob.addView(pill(t("ocr_download"), pal.accent, Color.WHITE) {
            val h = Handler(Looper.getMainLooper())
            Thread {
                val ok = OcrEngine.ensureData(this) { s -> h.post { ocStatus.text = s } }
                h.post { ocStatus.text = if (ok) t("ocr_ready") else t("ocr_failed_dl") }
            }.start()
        }, lp())
        oc.addView(ob, lp())

        // تشغيل سريع
        val qk = section(col, t("set_quick"))
        qk.addView(tv(t("quick_note"), 13f, pal.text).apply { setPadding(dp(14), dp(12), dp(14), dp(12)) }, lp())

        // حول
        val ab = section(col, t("set_about"))
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName ?: "" } catch (e: Exception) { "" }
        ab.addView(tv("QuickCopy", 16f, pal.text, true).apply { setPadding(dp(14), dp(12), dp(14), dp(2)) }, lp())
        ab.addView(tv(t("version") + ": " + ver, 13f, pal.sub).apply { setPadding(dp(14), 0, dp(14), dp(2)) }, lp())
        ab.addView(tv(t("privacy_note"), 13f, pal.sub).apply { setPadding(dp(14), dp(4), dp(14), dp(12)) }, lp())
        return sc
    }
}
