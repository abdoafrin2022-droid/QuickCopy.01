package com.example.quickcopy

import android.accessibilityservice.AccessibilityButtonController
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.speech.tts.TextToSpeech
import java.util.Locale
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

class CopyService : AccessibilityService() {

    companion object {
        @Volatile var instance: CopyService? = null
    }

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private var bubble: View? = null
    private var closeTarget: View? = null
    private var panelRoot: FrameLayout? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var card: View? = null
    private var selView: SelectionView? = null
    private var miniCopy: TextView? = null
    private var status: TextView? = null
    private var items = mutableListOf<Item>()
    private var busy = false
    private var bubbleX = -1
    private var bubbleY = -1
    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener {
        TextTools.captureClipboard(this)
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        instance = this
        if (getSharedPreferences("qc", MODE_PRIVATE).getBoolean("bubble", true)) showBubble()
        try {
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).addPrimaryClipChangedListener(clipListener)
        } catch (_: Exception) {
        }
        try {
            accessibilityButtonController.registerAccessibilityButtonCallback(
                object : AccessibilityButtonController.AccessibilityButtonCallback() {
                    override fun onClicked(controller: AccessibilityButtonController) {
                        openPanel()
                    }
                }
            )
        } catch (_: Throwable) {
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        cleanup()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    private fun cleanup() {
        instance = null
        TextTools.stop()
        try {
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).removePrimaryClipChangedListener(clipListener)
        } catch (_: Exception) {
        }
        closePanel()
        removeBubble()
        hideTarget()
    }

    /** يُستدعى من التطبيق لإظهار/إخفاء الزر العائم. */
    fun setBubbleEnabled(enabled: Boolean) {
        getSharedPreferences("qc", MODE_PRIVATE).edit().putBoolean("bubble", enabled).apply()
        if (enabled) showBubble() else { closePanel(); removeBubble() }
    }

    // ---------- الزر العائم ----------
    private fun removeBubble() {
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
    }

    private fun showTarget() {
        if (closeTarget != null) return
        val s = dp(64)
        val t = TextView(this).apply {
            text = "✕"; textSize = 26f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL; setColor(0xFFD32F2F.toInt())
            }
        }
        val lp = WindowManager.LayoutParams(
            s, s, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = dp(90) }
        try { wm.addView(t, lp); closeTarget = t } catch (_: Exception) {}
    }

    private fun hideTarget() {
        closeTarget?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        closeTarget = null
    }

    private fun overTarget(lp: WindowManager.LayoutParams, size: Int): Boolean {
        val dm = resources.displayMetrics
        val bx = lp.x + size / 2
        val by = lp.y + size / 2
        val tx = dm.widthPixels / 2
        val ty = dm.heightPixels - dp(90) - dp(32)
        return hypot((bx - tx).toDouble(), (by - ty).toDouble()) < dp(80)
    }

    /** يُستدعى من الإعدادات بعد تغيير حجم/شفافية الزر. */
    fun applyBubbleStyle() {
        if (bubble != null) {
            removeBubble()
            showBubble()
        }
    }

    /** فتح لوحة التحديد بعد قليل (من التطبيق نفسه). */
    fun openLater() {
        handler.postDelayed({ openPanel() }, 600)
    }

    /** فتح اللوحة من بلاطة الإعدادات السريعة. */
    fun openFromTile() {
        if (Build.VERSION.SDK_INT >= 31) performGlobalAction(GLOBAL_ACTION_DISMISS_NOTIFICATION_SHADE)
        handler.postDelayed({ openPanel() }, 600)
    }

    private fun showBubble() {
        if (bubble != null) return
        val prefs = getSharedPreferences("qc", MODE_PRIVATE)
        val sizeDp = prefs.getInt("bsize", 52)
        val size = dp(sizeDp)
        val v = TextView(this).apply {
            text = "📋"
            textSize = sizeDp * 0.42f
            gravity = Gravity.CENTER
            alpha = prefs.getInt("balpha", 90) / 100f
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFF1565C0.toInt())
            }
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = if (bubbleX >= 0) bubbleX else dp(8)
            y = if (bubbleY >= 0) bubbleY else dp(320)
        }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) {
                        showTarget()
                        lp.x = ox + dx; lp.y = oy + dy
                        bubbleX = lp.x; bubbleY = lp.y
                        try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) openPanel()
                    else {
                        val hit = overTarget(lp, size)
                        hideTarget()
                        if (hit) {
                            setBubbleEnabled(false)
                            toast(S.t(this@CopyService, "svc_bubble_hidden"))
                        }
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> { hideTarget(); true }
                else -> false
            }
        }
        wm.addView(v, lp)
        bubble = v
    }

    // ---------- قراءة النص من الشاشة ----------
    private fun collect(node: AccessibilityNodeInfo?, out: MutableList<Item>) {
        node ?: return
        if (node.isVisibleToUser) {
            var t = node.text?.toString()?.trim()
            if (t.isNullOrEmpty() && node.childCount == 0) {
                t = node.contentDescription?.toString()?.trim()
            }
            if (!t.isNullOrEmpty()) {
                val r = Rect()
                node.getBoundsInScreen(r)
                if (r.width() > 0 && r.height() > 0) out.add(Item(r, t))
            }
        }
        for (i in 0 until node.childCount) collect(node.getChild(i), out)
    }

    // ---------- لوحة التحديد ----------
    private fun btn(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        setTextColor(Color.WHITE)
        textSize = 15f
        gravity = Gravity.CENTER
        setPadding(dp(8), dp(10), dp(8), dp(10))
        background = GradientDrawable().apply {
            cornerRadius = dp(20).toFloat(); setColor(0xFF1565C0.toInt())
        }
        setOnClickListener { onClick() }
    }

    private fun openPanel() {
        if (panelRoot != null) return
        val prefs = getSharedPreferences("qc", MODE_PRIVATE)
        val list = mutableListOf<Item>()
        collect(rootInActiveWindow, list)
        items = list

        val root = FrameLayout(this)
        val sv = SelectionView(this, list, { updateStatus() }, { showCard(it) })
        sv.showBoxes = prefs.getBoolean("boxes", true)
        sv.onRegion = { r -> readRegion(r) }
        selView = sv
        root.addView(sv, FrameLayout.LayoutParams(-1, -1))

        val barWrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(2), dp(8), dp(6))
            background = GradientDrawable().apply {
                cornerRadius = dp(24).toFloat(); setColor(0xE6212121.toInt())
            }
        }
        val full = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val mini = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            visibility = View.GONE
        }
        val barLp = FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply {
            setMargins(dp(12), 0, dp(12), dp(40))
        }

        fun makeDraggable(h: View) {
            var px = 0f; var py = 0f; var tx = 0f; var ty = 0f
            h.setOnTouchListener { _, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        px = e.rawX; py = e.rawY; tx = barWrap.translationX; ty = barWrap.translationY
                    }
                    MotionEvent.ACTION_MOVE -> {
                        barWrap.translationX = tx + e.rawX - px
                        barWrap.translationY = ty + e.rawY - py
                    }
                }
                true
            }
        }

        fun setCollapsed(c: Boolean) {
            full.visibility = if (c) View.GONE else View.VISIBLE
            mini.visibility = if (c) View.VISIBLE else View.GONE
            barLp.width = if (c) -2 else -1
            barLp.gravity = if (c) (Gravity.BOTTOM or Gravity.END) else Gravity.BOTTOM
            barWrap.layoutParams = barLp
            barWrap.translationX = 0f
            barWrap.translationY = 0f
        }

        // ----- الشريط الكامل -----
        val st = TextView(this).apply {
            setTextColor(0xFFCCCCCC.toInt()); textSize = 11f
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        status = st
        makeDraggable(st)
        full.addView(st, LinearLayout.LayoutParams(-1, -2))

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        fun add(b: TextView, w: Float = 1f) {
            bar.addView(b, LinearLayout.LayoutParams(0, -2, w).apply {
                setMargins(dp(3), 0, dp(3), 0)
            })
        }
        add(btn(S.t(this@CopyService, "menu_copy")) { copySelected() }, 1.5f)
        add(btn(S.t(this@CopyService, "svc_all")) { items.forEach { it.selected = true }; root.invalidateAll(); updateStatus() }, 1.3f)
        add(btn("🖼") { startRegionMode() })
        add(btn("▦") {
            sv.showBoxes = !sv.showBoxes
            prefs.edit().putBoolean("boxes", sv.showBoxes).apply()
            sv.invalidate()
            toast(S.t(this@CopyService, if (sv.showBoxes) "svc_boxes_on" else "svc_boxes_off"))
        })
        add(btn("⌄") { setCollapsed(true) })
        add(btn("✕") { closePanel() })
        full.addView(bar, LinearLayout.LayoutParams(-1, -2))

        // ----- الشريط المصغّر -----
        val mHandle = TextView(this).apply {
            text = "⠿"; textSize = 20f; setTextColor(0xFFCCCCCC.toInt())
            setPadding(dp(10), dp(6), dp(10), dp(6))
        }
        makeDraggable(mHandle)
        val mCopy = btn(S.t(this@CopyService, "menu_copy")) { copySelected() }
        miniCopy = mCopy
        val mExpand = btn("⌃") { setCollapsed(false) }
        val mClose = btn("✕") { closePanel() }
        mini.addView(mHandle)
        mini.addView(mCopy, LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(3), 0, dp(3), 0) })
        mini.addView(mExpand, LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(3), 0, dp(3), 0) })
        mini.addView(mClose, LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(3), 0, dp(3), 0) })

        barWrap.addView(full, LinearLayout.LayoutParams(-1, -2))
        barWrap.addView(mini, LinearLayout.LayoutParams(-2, -2))
        root.addView(barWrap, barLp)

        val lp = WindowManager.LayoutParams(
            -1, -1,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(root, lp)
        panelRoot = root
        panelLp = lp
        bubble?.visibility = View.GONE
        updateStatus()
    }

    private fun View.invalidateAll() {
        invalidate()
        if (this is FrameLayout) for (i in 0 until childCount) getChildAt(i).invalidate()
    }

    private fun updateStatus() {
        val n = items.count { it.selected }
        miniCopy?.text = S.t(this@CopyService, "menu_copy") + " ($n)"
        status?.text = if (items.isEmpty()) S.t(this@CopyService, "svc_no_text")
        else S.t(this@CopyService, "svc_selected").format(n, items.size)
    }

    private fun closePanel() {
        closeCard()
        panelRoot?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panelRoot = null
        panelLp = null
        selView = null
        miniCopy = null
        status = null
        busy = false
        bubble?.visibility = View.VISIBLE
    }

    private fun area(i: Item) = i.rect.width().toLong() * i.rect.height()

    private fun copySelected() {
        val sel = items.filter { it.selected }
        if (sel.isEmpty()) { toast(S.t(this@CopyService, "svc_select_first")); return }
        // إذا كان مربع كبير يحتوي مربعات صغيرة محددة، نأخذ الصغيرة فقط لتجنب التكرار
        val chosen = sel.filter { a ->
            sel.none { b -> b !== a && area(b) < area(a) && a.rect.contains(b.rect.centerX(), b.rect.centerY()) }
        }.sortedWith(compareBy({ it.rect.top }, { it.rect.left }))
        copyText(chosen.joinToString("\n") { it.text })
    }

    private fun copyText(text: String) {
        TextTools.copy(this, text)
        toast(S.t(this@CopyService, "copied"))
        closePanel()
    }

    // ---------- بطاقة نسخ جملة معينة ----------
    private fun showCard(item: Item) {
        val root = panelRoot ?: return
        if (card != null) return

        val tv = TextView(this).apply {
            text = item.text
            textSize = 18f
            setTextColor(Color.WHITE)
            setTextIsSelectable(true)
            textDirection = View.TEXT_DIRECTION_ANY_RTL
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        val sc = ScrollView(this).apply { addView(tv) }
        val hint = TextView(this).apply {
            text = S.t(this@CopyService, "svc_card_hint")
            textSize = 12f
            setTextColor(0xFFBBBBBB.toInt())
            setPadding(dp(8), 0, dp(8), dp(8))
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        fun chosen(): String {
            val st0 = tv.selectionStart; val en0 = tv.selectionEnd
            val a0 = min(st0, en0); val b0 = max(st0, en0)
            return if (a0 >= 0 && b0 > a0) tv.text.subSequence(a0, b0).toString() else tv.text.toString()
        }
        fun addRow(b: TextView, w: Float) {
            row.addView(b, LinearLayout.LayoutParams(0, -2, w).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        addRow(btn(S.t(this@CopyService, "menu_copy")) { copyText(chosen()) }, 1.5f)
        addRow(btn("🔊") { speak(chosen()) }, 1f)
        addRow(btn("🌐") { translateText(chosen()) }, 1f)
        addRow(btn("↗") { shareText(chosen()) }, 1f)
        addRow(btn(S.t(this@CopyService, "svc_back")) { closeCard() }, 1.3f)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(20).toFloat(); setColor(0xF2212121.toInt())
            }
        }
        col.addView(hint)
        col.addView(sc, LinearLayout.LayoutParams(-1, (resources.displayMetrics.heightPixels * 0.35).toInt()))
        col.addView(row)
        root.addView(col, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER).apply {
            setMargins(dp(16), 0, dp(16), 0)
        })
        card = col

        // نجعل النافذة قابلة للتركيز حتى يعمل تحديد النص
        panelLp?.let {
            it.flags = it.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
            try { wm.updateViewLayout(root, it) } catch (_: Exception) {}
        }
    }

    private fun closeCard() {
        TextTools.stop()
        card?.let { c -> panelRoot?.removeView(c) }
        card = null
        val root = panelRoot
        panelLp?.let {
            it.flags = it.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            if (root != null) try { wm.updateViewLayout(root, it) } catch (_: Exception) {}
        }
    }

    // ---------- قراءة النص من صورة (OCR) ----------
    private fun startRegionMode() {
        if (busy) return
        selView?.regionMode = true
        status?.text = S.t(this@CopyService, "svc_draw_box")
        toast(S.t(this@CopyService, "svc_draw_box"))
    }

    private fun grabScreen(done: (Bitmap?) -> Unit) {
        val root = panelRoot ?: run { done(null); return }
        root.visibility = View.INVISIBLE
        handler.postDelayed({
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(result: ScreenshotResult) {
                    val hb = result.hardwareBuffer
                    val bmp = Bitmap.wrapHardwareBuffer(hb, result.colorSpace)
                        ?.copy(Bitmap.Config.ARGB_8888, false)
                    hb.close()
                    panelRoot?.visibility = View.VISIBLE
                    done(bmp)
                }

                override fun onFailure(errorCode: Int) {
                    panelRoot?.visibility = View.VISIBLE
                    done(null)
                }
            })
        }, 300)
    }

    private fun readRegion(region: Rect) {
        if (busy) return
        busy = true
        status?.text = S.t(this@CopyService, "svc_preparing")
        Thread {
            val ok = OcrEngine.ensureData(this) { s -> handler.post { status?.text = s } }
            handler.post {
                if (!ok) {
                    status?.text = S.t(this@CopyService, "svc_dl_fail")
                    busy = false
                    return@post
                }
                grabScreen { bmp ->
                    if (bmp == null) {
                        status?.text = S.t(this@CopyService, "svc_shot_fail")
                        busy = false
                        return@grabScreen
                    }
                    status?.text = S.t(this@CopyService, "svc_reading")
                    Thread {
                        var err: String? = null
                        val text = try {
                            val l = max(0, region.left)
                            val t = max(0, region.top)
                            val r = min(bmp.width, region.right)
                            val b = min(bmp.height, region.bottom)
                            if (r - l < 20 || b - t < 20) ""
                            else OcrEngine.recognizeRegion(this, Bitmap.createBitmap(bmp, l, t, r - l, b - t))
                        } catch (e: Throwable) {
                            err = e.message ?: e.javaClass.simpleName
                            ""
                        }
                        handler.post {
                            busy = false
                            if (err != null) {
                                status?.text = S.t(this@CopyService, "svc_ocr_err") + " " + err
                                return@post
                            }
                            if (text.isBlank()) {
                                status?.text = S.t(this@CopyService, "svc_ocr_empty")
                                return@post
                            }
                            updateStatus()
                            showCard(Item(region, text))
                        }
                    }.start()
                }
            }
        }.start()
    }

    // ---------- قراءة صوتية / ترجمة / مشاركة ----------
    private fun speak(text: String) {
        if (text.isBlank()) return
        if (TextTools.isSpeaking()) { TextTools.stop(); return }
        val pref = getSharedPreferences("qc", MODE_PRIVATE).getString("ttslang", "auto") ?: "auto"
        val lang = if (pref == "ar" || pref == "en") pref else TextTools.detectLang(text)
        TextTools.speak(this, text, lang) { ev ->
            when (ev) {
                "missing_data" -> toast(S.t(this@CopyService, "tts_missing"))
                "no_engine" -> toast(S.t(this@CopyService, "tts_noengine"))
                "preparing" -> toast(S.t(this@CopyService, "tts_preparing"))
                "error" -> toast(S.t(this@CopyService, "tts_error"))
                else -> {}
            }
        }
    }

    private fun shareText(text: String) {
        if (TextTools.share(this, text)) closePanel() else toast(S.t(this, "share_fail"))
    }

    private fun translateText(text: String) {
        if (TextTools.translate(this, text)) closePanel() else toast(S.t(this, "tr_fail"))
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
