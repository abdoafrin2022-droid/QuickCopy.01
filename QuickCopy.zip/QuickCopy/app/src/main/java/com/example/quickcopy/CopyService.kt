package com.example.quickcopy

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.content.ClipData
import android.content.ClipboardManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

class CopyService : AccessibilityService() {

    companion object {
        @Volatile var instance: CopyService? = null
    }

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private var bubble: View? = null
    private var closeTarget: View? = null
    private var panelRoot: FrameLayout? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var card: View? = null
    private var status: TextView? = null
    private var items = mutableListOf<Item>()
    private var busy = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        instance = this
        if (getSharedPreferences("qc", MODE_PRIVATE).getBoolean("bubble", true)) showBubble()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        cleanup()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    private fun cleanup() {
        instance = null
        closePanel()
        removeBubble()
        hideTarget()
    }

    /** يُستدعى من التطبيق لإظهار/إخفاء الزر العائم. */
    fun setBubbleEnabled(enabled: Boolean) {
        getSharedPreferences("qc", MODE_PRIVATE).edit().putBoolean("bubble", enabled).apply()
        if (enabled) showBubble() else { closePanel(); removeBubble() }
    }

    // ---------- الزر العائم ----------
    private fun removeBubble() {
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
    }

    private fun showTarget() {
        if (closeTarget != null) return
        val s = dp(64)
        val t = TextView(this).apply {
            text = "✕"; textSize = 26f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL; setColor(0xFFD32F2F.toInt())
            }
        }
        val lp = WindowManager.LayoutParams(
            s, s, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = dp(90) }
        try { wm.addView(t, lp); closeTarget = t } catch (_: Exception) {}
    }

    private fun hideTarget() {
        closeTarget?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        closeTarget = null
    }

    private fun overTarget(lp: WindowManager.LayoutParams): Boolean {
        val dm = resources.displayMetrics
        val bx = lp.x + dp(26)
        val by = lp.y + dp(26)
        val tx = dm.widthPixels / 2
        val ty = dm.heightPixels - dp(90) - dp(32)
        return hypot((bx - tx).toDouble(), (by - ty).toDouble()) < dp(80)
    }

    private fun showBubble() {
        if (bubble != null) return
        val size = dp(52)
        val v = TextView(this).apply {
            text = "📋"
            textSize = 22f
            gravity = Gravity.CENTER
            alpha = 0.9f
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFF1565C0.toInt())
            }
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8); y = dp(320)
        }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) {
                        showTarget()
                        lp.x = ox + dx; lp.y = oy + dy
                        try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) openPanel()
                    else {
                        val hit = overTarget(lp)
                        hideTarget()
                        if (hit) {
                            setBubbleEnabled(false)
                            toast("تم إخفاء الزر. لإظهاره افتح تطبيق «نسخ سريع» واضغط زر الإظهار")
                        }
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> { hideTarget(); true }
                else -> false
            }
        }
        wm.addView(v, lp)
        bubble = v
    }

    // ---------- قراءة النص من الشاشة ----------
    private fun collect(node: AccessibilityNodeInfo?, out: MutableList<Item>) {
        node ?: return
        if (node.isVisibleToUser) {
            var t = node.text?.toString()?.trim()
            if (t.isNullOrEmpty() && node.childCount == 0) {
                t = node.contentDescription?.toString()?.trim()
            }
            if (!t.isNullOrEmpty()) {
                val r = Rect()
                node.getBoundsInScreen(r)
                if (r.width() > 0 && r.height() > 0) out.add(Item(r, t))
            }
        }
        for (i in 0 until node.childCount) collect(node.getChild(i), out)
    }

    // ---------- لوحة التحديد ----------
    private fun btn(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        setTextColor(Color.WHITE)
        textSize = 15f
        gravity = Gravity.CENTER
        setPadding(dp(8), dp(10), dp(8), dp(10))
        background = GradientDrawable().apply {
            cornerRadius = dp(20).toFloat(); setColor(0xFF1565C0.toInt())
        }
        setOnClickListener { onClick() }
    }

    private fun openPanel() {
        if (panelRoot != null) return
        val list = mutableListOf<Item>()
        collect(rootInActiveWindow, list)
        items = list

        val root = FrameLayout(this)
        root.addView(
            SelectionView(this, list, { updateStatus() }, { showCard(it) }),
            FrameLayout.LayoutParams(-1, -1)
        )

        val barWrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(2), dp(8), dp(8))
            background = GradientDrawable().apply {
                cornerRadius = dp(24).toFloat(); setColor(0xE6212121.toInt())
            }
        }
        val st = TextView(this).apply {
            setTextColor(0xFFCCCCCC.toInt()); textSize = 11f
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        status = st
        var px = 0f; var py = 0f; var tx = 0f; var ty = 0f
        st.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    px = e.rawX; py = e.rawY; tx = barWrap.translationX; ty = barWrap.translationY
                }
                MotionEvent.ACTION_MOVE -> {
                    barWrap.translationX = tx + e.rawX - px
                    barWrap.translationY = ty + e.rawY - py
                }
            }
            true
        }
        barWrap.addView(st, LinearLayout.LayoutParams(-1, -2))

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        fun add(b: TextView) {
            bar.addView(b, LinearLayout.LayoutParams(0, -2, 1f).apply {
                setMargins(dp(4), 0, dp(4), 0)
            })
        }
        add(btn("نسخ") { copySelected() })
        add(btn("الكل") { items.forEach { it.selected = true }; root.invalidateAll(); updateStatus() })
        add(btn("صور OCR") { runOcr() })
        add(btn("إغلاق") { closePanel() })
        barWrap.addView(bar, LinearLayout.LayoutParams(-1, -2))
        root.addView(
            barWrap,
            FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply {
                setMargins(dp(12), 0, dp(12), dp(40))
            }
        )

        val lp = WindowManager.LayoutParams(
            -1, -1,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(root, lp)
        panelRoot = root
        panelLp = lp
        bubble?.visibility = View.GONE
        updateStatus()
    }

    private fun View.invalidateAll() {
        invalidate()
        if (this is FrameLayout) for (i in 0 until childCount) getChildAt(i).invalidate()
    }

    private fun updateStatus() {
        val n = items.count { it.selected }
        status?.text = if (items.isEmpty()) "ما لقيت نص — جرّب صور OCR • اسحب هنا لتحريك الشريط"
        else "محدد $n من ${items.size} • اسحب هنا لتحريك الشريط"
    }

    private fun closePanel() {
        closeCard()
        panelRoot?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panelRoot = null
        panelLp = null
        status = null
        busy = false
        bubble?.visibility = View.VISIBLE
    }

    private fun area(i: Item) = i.rect.width().toLong() * i.rect.height()

    private fun copySelected() {
        val sel = items.filter { it.selected }
        if (sel.isEmpty()) { toast("حدد نصاً أولاً"); return }
        // إذا كان مربع كبير يحتوي مربعات صغيرة محددة، نأخذ الصغيرة فقط لتجنب التكرار
        val chosen = sel.filter { a ->
            sel.none { b -> b !== a && area(b) < area(a) && a.rect.contains(b.rect.centerX(), b.rect.centerY()) }
        }.sortedWith(compareBy({ it.rect.top }, { it.rect.left }))
        copyText(chosen.joinToString("\n") { it.text })
    }

    private fun copyText(text: String) {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("QuickCopy", text))
        toast("تم النسخ ✓")
        closePanel()
    }

    // ---------- بطاقة نسخ جملة معينة ----------
    private fun showCard(item: Item) {
        val root = panelRoot ?: return
        if (card != null) return

        val tv = TextView(this).apply {
            text = item.text
            textSize = 18f
            setTextColor(Color.WHITE)
            setTextIsSelectable(true)
            textDirection = View.TEXT_DIRECTION_ANY_RTL
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        val sc = ScrollView(this).apply { addView(tv) }
        val hint = TextView(this).apply {
            text = "اضغط مطولاً على كلمة ثم اسحب لتحديد الجملة، ثم اضغط «نسخ». بدون تحديد ينسخ الكل."
            textSize = 12f
            setTextColor(0xFFBBBBBB.toInt())
            setPadding(dp(8), 0, dp(8), dp(8))
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val copyBtn = btn("نسخ") {
            val s = tv.selectionStart; val e = tv.selectionEnd
            val a = min(s, e); val b = max(s, e)
            val t = if (a >= 0 && b > a) tv.text.subSequence(a, b).toString() else tv.text.toString()
            copyText(t)
        }
        val backBtn = btn("رجوع") { closeCard() }
        row.addView(copyBtn, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(4), 0, dp(4), 0) })
        row.addView(backBtn, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(4), 0, dp(4), 0) })

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(20).toFloat(); setColor(0xF2212121.toInt())
            }
        }
        col.addView(hint)
        col.addView(sc, LinearLayout.LayoutParams(-1, (resources.displayMetrics.heightPixels * 0.35).toInt()))
        col.addView(row)
        root.addView(col, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER).apply {
            setMargins(dp(16), 0, dp(16), 0)
        })
        card = col

        // نجعل النافذة قابلة للتركيز حتى يعمل تحديد النص
        panelLp?.let {
            it.flags = it.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
            try { wm.updateViewLayout(root, it) } catch (_: Exception) {}
        }
    }

    private fun closeCard() {
        card?.let { c -> panelRoot?.removeView(c) }
        card = null
        val root = panelRoot
        panelLp?.let {
            it.flags = it.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            if (root != null) try { wm.updateViewLayout(root, it) } catch (_: Exception) {}
        }
    }

    // ---------- OCR للصور ----------
    private fun runOcr() {
        if (busy) return
        busy = true
        status?.text = "جاري التجهيز..."
        Thread {
            val ok = OcrEngine.ensureData(this) { s -> handler.post { status?.text = s } }
            handler.post {
                if (!ok) {
                    status?.text = "تعذر تحميل لغات OCR — تأكد من الإنترنت"
                    busy = false
                } else capture()
            }
        }.start()
    }

    private fun capture() {
        val root = panelRoot ?: run { busy = false; return }
        root.visibility = View.INVISIBLE
        handler.postDelayed({
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(result: ScreenshotResult) {
                    val hb = result.hardwareBuffer
                    val bmp = Bitmap.wrapHardwareBuffer(hb, result.colorSpace)
                        ?.copy(Bitmap.Config.ARGB_8888, false)
                    hb.close()
                    panelRoot?.visibility = View.VISIBLE
                    if (bmp == null) { status?.text = "فشل التقاط الشاشة"; busy = false; return }
                    status?.text = "جاري قراءة الصور... قد تستغرق عدة ثوانٍ"
                    Thread {
                        var err: String? = null
                        val res = try {
                            OcrEngine.recognize(this@CopyService, bmp)
                        } catch (e: Throwable) {
                            err = e.message ?: e.javaClass.simpleName
                            emptyList()
                        }
                        handler.post {
                            // نضيف سطر OCR إلا إذا كان نفس سطر نصي موجود أصلاً (مربع بحجم السطر نفسه)
                            val add = res.filter { (r, _) ->
                                items.none {
                                    it.rect.contains(r.centerX(), r.centerY()) &&
                                        it.rect.height() <= r.height() * 2.5
                                }
                            }.map { Item(it.first, it.second) }
                            items.addAll(add)
                            panelRoot?.invalidateAll()
                            updateStatus()
                            if (err != null) toast("خطأ OCR: $err")
                            else if (add.isEmpty()) toast("ما لقيت نص إضافي في الصور")
                            else toast("أضفت ${add.size} سطراً من الصور")
                            busy = false
                        }
                    }.start()
                }

                override fun onFailure(errorCode: Int) {
                    panelRoot?.visibility = View.VISIBLE
                    status?.text = "تعذر التقاط الشاشة (التطبيق قد يمنع التصوير)"
                    busy = false
                }
            })
        }, 300)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
