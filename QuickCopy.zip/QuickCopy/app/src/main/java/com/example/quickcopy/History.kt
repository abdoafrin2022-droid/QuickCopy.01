package com.example.quickcopy

import android.content.Context
import org.json.JSONArray

object History {
    private const val KEY = "history"
    private const val MAX = 30

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("qc", Context.MODE_PRIVATE)

    fun load(ctx: Context): List<String> {
        val s = prefs(ctx).getString(KEY, null) ?: return emptyList()
        return try {
            val ja = JSONArray(s)
            (0 until ja.length()).map { ja.getString(it) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun add(ctx: Context, text: String) {
        if (text.isBlank()) return
        val list = load(ctx).toMutableList()
        list.remove(text)
        list.add(0, text)
        while (list.size > MAX) list.removeAt(list.size - 1)
        val ja = JSONArray()
        list.forEach { ja.put(it) }
        prefs(ctx).edit().putString(KEY, ja.toString()).apply()
    }

    fun clear(ctx: Context) {
        prefs(ctx).edit().remove(KEY).apply()
    }
}
