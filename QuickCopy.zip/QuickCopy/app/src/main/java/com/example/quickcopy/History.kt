package com.example.quickcopy

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** سجل النسخ المحفوظ على الجهاز فقط (آخر 30 عنصراً غير مفضل + المفضلة). */
object History {
    data class Entry(val id: Long, val text: String, val ts: Long, val fav: Boolean)

    const val MAX = 30
    private const val MAX_LEN = 20000
    private const val KEY = "clips2"
    private const val OLD = "history"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("qc", Context.MODE_PRIVATE)

    @Synchronized
    fun all(ctx: Context): List<Entry> {
        val p = prefs(ctx)
        val s = p.getString(KEY, null)
        if (s == null) return migrate(ctx)
        return parse(s)
    }

    private fun parse(s: String): List<Entry> = try {
        val ja = JSONArray(s)
        (0 until ja.length()).map {
            val o = ja.getJSONObject(it)
            Entry(o.getLong("id"), o.getString("text"), o.getLong("ts"), o.optBoolean("fav", false))
        }
    } catch (e: Exception) {
        emptyList()
    }

    private fun migrate(ctx: Context): List<Entry> {
        val old = prefs(ctx).getString(OLD, null) ?: return emptyList()
        return try {
            val ja = JSONArray(old)
            val now = System.currentTimeMillis()
            val list = (0 until ja.length()).map { i ->
                Entry(now - i, ja.getString(i), now - i * 1000L, false)
            }
            save(ctx, list)
            list
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun save(ctx: Context, list: List<Entry>) {
        val ja = JSONArray()
        for (e in list) {
            ja.put(JSONObject().put("id", e.id).put("text", e.text).put("ts", e.ts).put("fav", e.fav))
        }
        prefs(ctx).edit().putString(KEY, ja.toString()).apply()
    }

    private fun newId(list: List<Entry>): Long {
        var id = System.currentTimeMillis()
        while (list.any { it.id == id }) id++
        return id
    }

    private fun trim(list: MutableList<Entry>) {
        var count = 0
        val it = list.iterator()
        while (it.hasNext()) {
            val e = it.next()
            if (!e.fav) {
                count++
                if (count > MAX) it.remove()
            }
        }
    }

    /** يضيف نصاً (أو يرفع المكرر إلى الأعلى). يعيد true إذا حُفظ. */
    @Synchronized
    fun add(ctx: Context, text: String): Boolean {
        val t = text.trim().take(MAX_LEN)
        if (t.isEmpty()) return false
        val list = all(ctx).toMutableList()
        val now = System.currentTimeMillis()
        val idx = list.indexOfFirst { it.text == t }
        if (idx >= 0) {
            val e = list.removeAt(idx)
            list.add(0, e.copy(ts = now))
        } else {
            list.add(0, Entry(newId(list), t, now, false))
        }
        trim(list)
        save(ctx, list)
        return true
    }

    @Synchronized
    fun update(ctx: Context, id: Long, newText: String): Boolean {
        val t = newText.trim().take(MAX_LEN)
        if (t.isEmpty()) return false
        val list = all(ctx).toMutableList()
        val idx = list.indexOfFirst { it.id == id }
        if (idx < 0) return false
        val cur = list[idx]
        // إذا وُجد عنصر آخر بنفس النص ندمجهما
        val dup = list.indexOfFirst { it.id != id && it.text == t }
        val merged = cur.copy(text = t, fav = cur.fav || (dup >= 0 && list[dup].fav))
        list[idx] = merged
        if (dup >= 0) list.removeAt(dup)
        save(ctx, list)
        return true
    }

    @Synchronized
    fun toggleFav(ctx: Context, id: Long) {
        val list = all(ctx).toMutableList()
        val idx = list.indexOfFirst { it.id == id }
        if (idx < 0) return
        list[idx] = list[idx].copy(fav = !list[idx].fav)
        trim(list)
        save(ctx, list)
    }

    @Synchronized
    fun delete(ctx: Context, id: Long) {
        save(ctx, all(ctx).filter { it.id != id })
    }

    @Synchronized
    fun clear(ctx: Context, keepFavorites: Boolean) {
        save(ctx, if (keepFavorites) all(ctx).filter { it.fav } else emptyList())
    }
}
