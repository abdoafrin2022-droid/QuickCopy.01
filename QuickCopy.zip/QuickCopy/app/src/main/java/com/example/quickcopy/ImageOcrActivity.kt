package com.example.quickcopy

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Typeface
import android.media.ExifInterface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowInsetsController
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.max

class ImageOcrActivity : Activity() {

    private class Row(val text: String) {
        lateinit var view: TextView
        var sel = false
    }

    private lateinit var pal: Pal
    private val rows = mutableListOf<Row>()
    private lateinit var status: TextView
    private lateinit var image: ImageView
    private lateinit var listBox: LinearLayout
    private lateinit var merge: CheckBox

    private fun t(k: String) = S.t(this, k)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun tv(text: String, size: Float = 15f, color: Int = pal.text, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            textDirection = View.TEXT_DIRECTION_ANY_RTL
        }

    private fun pill(label: String, fill: Int, color: Int, onClick: () -> Unit) =
        tv(label, 14f, color, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(12), dp(8), dp(12))
            background = rounded(fill, 14)
            isClickable = true
            setOnClickListener { onClick() }
        }

    private fun textOf(list: List<Row>) = list.joinToString(if (merge.isChecked) " " else "\n") { it.text }

    private fun chosenOrAll(): String {
        val s = rows.filter { it.sel }
        return textOf(if (s.isEmpty()) rows else s)
    }

    private fun paint(r: Row) {
        r.view.background = if (r.sel) rounded(0x6643A047, 12) else rounded(pal.card, 12, pal.stroke)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        val dark = isDarkMode(this)
        setTheme(if (dark) android.R.style.Theme_Material_NoActionBar else android.R.style.Theme_Material_Light_NoActionBar)
        super.onCreate(savedInstanceState)
        pal = Pal(dark)
        val rtl = S.isRtl(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(pal.bg)
            layoutDirection = if (rtl) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
            setPadding(dp(14), dp(14), dp(14), dp(12))
        }
        status = tv("", 14f, pal.sub).apply { setPadding(0, 0, 0, dp(8)) }
        image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            background = rounded(pal.card, 14, pal.stroke)
        }
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        merge = CheckBox(this).apply {
            text = t("img_merge")
            setTextColor(pal.text)
        }

        root.addView(tv(t("tool_image"), 20f, pal.text, true))
        root.addView(status)
        root.addView(image, LinearLayout.LayoutParams(-1, (resources.displayMetrics.heightPixels * 0.22).toInt()))
        root.addView(
            ScrollView(this).apply { addView(listBox) },
            LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(10) }
        )
        root.addView(merge)

        fun rowOf(vararg bs: TextView) {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for ((i, b) in bs.withIndex()) {
                r.addView(b, LinearLayout.LayoutParams(0, -2, 1f).apply {
                    marginStart = if (i == 0) 0 else dp(4)
                    marginEnd = if (i == bs.size - 1) 0 else dp(4)
                })
            }
            root.addView(r, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        }

        rowOf(
            pill(t("img_copy_sel"), pal.accent, Color.WHITE) {
                val s = rows.filter { it.sel }
                if (s.isEmpty()) toast(t("img_select_first"))
                else { TextTools.copy(this, textOf(s)); toast(t("copied")) }
            },
            pill(t("img_copy_all"), pal.card2, pal.text) {
                if (rows.isEmpty()) toast(t("img_no_text"))
                else { TextTools.copy(this, textOf(rows)); toast(t("copied")) }
            },
            pill(t("img_select_all"), pal.card2, pal.text) {
                val all = rows.isNotEmpty() && rows.all { it.sel }
                rows.forEach { it.sel = !all; paint(it) }
            }
        )
        rowOf(
            pill("🔊", pal.card2, pal.text) {
                val x = chosenOrAll()
                TextTools.speak(this, x, TextTools.detectLang(x)) { ev ->
                    when (ev) {
                        "missing_data" -> toast(t("tts_missing"))
                        "no_engine" -> toast(t("tts_noengine"))
                        "preparing" -> toast(t("tts_preparing"))
                        "error" -> toast(t("tts_error"))
                        else -> {}
                    }
                }
            },
            pill("🌐", pal.card2, pal.text) {
                if (!TextTools.translate(this, chosenOrAll())) toast(t("tr_fail"))
            },
            pill("↗", pal.card2, pal.text) {
                if (!TextTools.share(this, chosenOrAll())) toast(t("share_fail"))
            }
        )

        setContentView(root)
        window.statusBarColor = pal.bg
        window.navigationBarColor = pal.bg
        val mask = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
        window.insetsController?.setSystemBarsAppearance(if (dark) 0 else mask, mask)

        val uri: Uri? = intent.data ?: if (intent.action == Intent.ACTION_SEND)
            intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM) else null
        if (uri == null) {
            status.text = t("img_no_image")
            return
        }
        status.text = t("img_status_open")
        Thread {
            try {
                val bmp = loadBitmap(uri)
                if (bmp == null) {
                    runOnUiThread { status.text = t("img_open_fail") }
                    return@Thread
                }
                runOnUiThread { image.setImageBitmap(bmp); status.text = t("img_preparing") }
                val ok = OcrEngine.ensureData(this) { s -> runOnUiThread { status.text = s } }
                if (!ok) {
                    runOnUiThread { status.text = t("ocr_dl_fail") }
                    return@Thread
                }
                runOnUiThread { status.text = t("img_reading") }
                val lines = OcrEngine.recognizeLines(this, bmp)
                runOnUiThread { showLines(lines) }
            } catch (e: Throwable) {
                runOnUiThread { status.text = t("error") + ": " + (e.message ?: e.javaClass.simpleName) }
            }
        }.start()
    }

    private fun showLines(lines: List<String>) {
        listBox.removeAllViews()
        rows.clear()
        if (lines.isEmpty()) {
            status.text = t("img_empty")
            return
        }
        status.text = t("img_done")
        for (line in lines) {
            val row = Row(line)
            val v = tv(line, 17f).apply {
                setPadding(dp(12), dp(10), dp(12), dp(10))
                gravity = Gravity.START
                setOnClickListener { row.sel = !row.sel; paint(row) }
            }
            row.view = v
            paint(row)
            rows.add(row)
            listBox.addView(v, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })
        }
    }

    private fun loadBitmap(uri: Uri): Bitmap? {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        var sample = 1
        while (max(opts.outWidth, opts.outHeight) / sample > 3000) sample *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
            ?: return null
        val rot = try {
            contentResolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            } ?: ExifInterface.ORIENTATION_NORMAL
        } catch (e: Exception) {
            ExifInterface.ORIENTATION_NORMAL
        }
        val deg = when (rot) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        if (deg == 0f) return bmp
        val m = Matrix().apply { postRotate(deg) }
        return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    }

    override fun onDestroy() {
        TextTools.stop()
        super.onDestroy()
    }
}
