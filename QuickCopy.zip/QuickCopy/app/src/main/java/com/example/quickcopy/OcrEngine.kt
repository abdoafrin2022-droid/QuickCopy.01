package com.example.quickcopy

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Rect
import com.googlecode.tesseract.android.TessBaseAPI
import java.io.File
import java.net.URL
import kotlin.math.max

object OcrEngine {
    private val langs = listOf("ara", "eng")

    private fun baseDir(ctx: Context) = File(ctx.filesDir, "tess2")

    fun hasData(ctx: Context): Boolean {
        val dir = File(baseDir(ctx), "tessdata")
        return langs.all { File(dir, "$it.traineddata").let { f -> f.exists() && f.length() > 500_000 } }
    }

    private fun download(url: String, dest: File): Boolean {
        return try {
            val conn = URL(url).openConnection()
            conn.connectTimeout = 20000
            conn.readTimeout = 60000
            val tmp = File(dest.parentFile, dest.name + ".tmp")
            conn.getInputStream().use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
            tmp.renameTo(dest)
        } catch (e: Exception) {
            false
        }
    }

    /** يحمّل ملفات اللغة مرة واحدة (الدقيقة أولاً، وإلا السريعة). يحتاج إنترنت. */
    fun ensureData(ctx: Context, onStatus: (String) -> Unit): Boolean {
        val dir = File(baseDir(ctx), "tessdata")
        dir.mkdirs()
        for (l in langs) {
            val f = File(dir, "$l.traineddata")
            if (f.exists() && f.length() > 500_000) continue
            onStatus(S.t(ctx, "dl_lang") + " " + l)
            val ok = download("https://github.com/tesseract-ocr/tessdata_best/raw/main/$l.traineddata", f) ||
                download("https://github.com/tesseract-ocr/tessdata_fast/raw/main/$l.traineddata", f)
            if (!ok) return false
        }
        return hasData(ctx)
    }

    private fun filtered(src: Bitmap, scale: Float, invert: Boolean): Bitmap {
        val w = (src.width * scale).toInt().coerceAtLeast(1)
        val h = (src.height * scale).toInt().coerceAtLeast(1)
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cm = ColorMatrix().apply { setSaturation(0f) }
        val k = 1.5f
        val t = (-0.5f * k + 0.5f) * 255f
        cm.postConcat(ColorMatrix(floatArrayOf(
            k, 0f, 0f, 0f, t,
            0f, k, 0f, 0f, t,
            0f, 0f, k, 0f, t,
            0f, 0f, 0f, 1f, 0f
        )))
        if (invert) {
            cm.postConcat(ColorMatrix(floatArrayOf(
                -1f, 0f, 0f, 0f, 255f,
                0f, -1f, 0f, 0f, 255f,
                0f, 0f, -1f, 0f, 255f,
                0f, 0f, 0f, 1f, 0f
            )))
        }
        val p = Paint(Paint.FILTER_BITMAP_FLAG).apply { colorFilter = ColorMatrixColorFilter(cm) }
        Canvas(out).drawBitmap(src, null, Rect(0, 0, w, h), p)
        return out
    }

    /** يقرأ النص من منطقة مقصوصة. يجرب نسخة عادية ونسخة معكوسة الألوان ويختار الأفضل. */
    fun recognizeRegion(ctx: Context, crop: Bitmap): String {
        val scale = (1800f / crop.width).coerceIn(1f, 3f)
        val api = TessBaseAPI()
        try {
            if (!api.init(baseDir(ctx).absolutePath, "ara+eng")) return ""
            api.setPageSegMode(TessBaseAPI.PageSegMode.PSM_AUTO)
            var best = ""
            var bestConf = -1
            for (inv in listOf(false, true)) {
                val b = filtered(crop, scale, inv)
                api.setImage(b)
                val t = api.getUTF8Text()?.trim() ?: ""
                val c = api.meanConfidence()
                if (t.isNotBlank() && c > bestConf) { best = t; bestConf = c }
            }
            return best
        } finally {
            api.recycle()
        }
    }

    /** يقرأ صورة كاملة ويعيد الأسطر بترتيبها. */
    fun recognizeLines(ctx: Context, src: Bitmap): List<String> {
        val longSide = max(src.width, src.height).toFloat()
        val scale = when {
            longSide > 2400f -> 2400f / longSide
            src.width < 1200 -> (1200f / src.width).coerceAtMost(3f)
            else -> 1f
        }
        val api = TessBaseAPI()
        try {
            if (!api.init(baseDir(ctx).absolutePath, "ara+eng")) return emptyList()
            api.setPageSegMode(TessBaseAPI.PageSegMode.PSM_AUTO)
            var best = ""
            var bestConf = -1
            for (inv in listOf(false, true)) {
                val b = filtered(src, scale, inv)
                api.setImage(b)
                val t = api.getUTF8Text()?.trim() ?: ""
                val c = api.meanConfidence()
                if (t.isNotBlank() && c > bestConf) { best = t; bestConf = c }
            }
            return best.lines().map { it.trim() }.filter { it.isNotEmpty() }
        } finally {
            api.recycle()
        }
    }
}
