plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.quickcopy"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.quickcopy"
        minSdk = 30
        targetSdk = 34
        versionCode = 3
        versionName = "3.0"
    }

    // مفتاح توقيع ثابت: يضمن أن كل نسخة جديدة تُحدّث التي قبلها بدون حذف
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("cz.adaptech.tesseract4android:tesseract4android:4.7.0")
}
