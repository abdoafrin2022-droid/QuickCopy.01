package com.example.quickcopy

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import com.googlecode.tesseract.android.TessBaseAPI
import java.io.File
import java.net.URL

object OcrEngine {
    private val langs = listOf("ara", "eng")

    private fun baseDir(ctx: Context) = File(ctx.filesDir, "tess")

    fun hasData(ctx: Context): Boolean {
        val dir = File(baseDir(ctx), "tessdata")
        return langs.all { File(dir, "$it.traineddata").let { f -> f.exists() && f.length() > 100_000 } }
    }

    /** يحمّل ملفات اللغة مرة واحدة (يحتاج إنترنت). */
    fun ensureData(ctx: Context, onStatus: (String) -> Unit): Boolean {
        val dir = File(baseDir(ctx), "tessdata")
        dir.mkdirs()
        for (l in langs) {
            val f = File(dir, "$l.traineddata")
            if (f.exists() && f.length() > 100_000) continue
            try {
                onStatus("جاري تحميل لغة $l ...")
                val tmp = File(dir, "$l.tmp")
                URL("https://github.com/tesseract-ocr/tessdata_fast/raw/main/$l.traineddata")
                    .openStream().use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                tmp.renameTo(f)
            } catch (e: Exception) {
                return false
            }
        }
        return hasData(ctx)
    }

    fun recognize(ctx: Context, bmp: Bitmap): List<Pair<Rect, String>> {
        val out = ArrayList<Pair<Rect, String>>()
        val api = TessBaseAPI()
        try {
            if (!api.init(baseDir(ctx).absolutePath, "ara+eng")) return out
            api.setPageSegMode(TessBaseAPI.PageSegMode.PSM_AUTO)
            api.setImage(bmp)
            api.getUTF8Text() // يشغّل التعرف
            val it = api.resultIterator ?: return out
            val level = TessBaseAPI.PageIteratorLevel.RIL_TEXTLINE
            it.begin()
            do {
                val t = it.getUTF8Text(level)?.trim()
                val r = it.getBoundingRect(level)
                if (!t.isNullOrBlank() && r != null && it.confidence(level) > 45f) {
                    out.add(Pair(Rect(r), t))
                }
            } while (it.next(level))
            it.delete()
        } finally {
            api.recycle()
        }
        return out
    }
}
