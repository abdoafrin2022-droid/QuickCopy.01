package com.example.quickcopy

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.content.ClipData
import android.content.ClipboardManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class CopyService : AccessibilityService() {

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private var bubble: View? = null
    private var panelRoot: FrameLayout? = null
    private var status: TextView? = null
    private var items = mutableListOf<Item>()
    private var busy = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        closePanel()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
        super.onDestroy()
    }

    // ---------- الزر العائم ----------
    private fun showBubble() {
        if (bubble != null) return
        val size = dp(52)
        val v = TextView(this).apply {
            text = "📋"
            textSize = 22f
            gravity = Gravity.CENTER
            alpha = 0.9f
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFF1565C0.toInt())
            }
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8); y = dp(320)
        }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) { lp.x = ox + dx; lp.y = oy + dy; wm.updateViewLayout(v, lp) }
                    true
                }
                MotionEvent.ACTION_UP -> { if (!moved) openPanel(); true }
                else -> false
            }
        }
        wm.addView(v, lp)
        bubble = v
    }

    // ---------- قراءة النص من الشاشة ----------
    private fun collect(node: AccessibilityNodeInfo?, out: MutableList<Item>) {
        node ?: return
        if (node.isVisibleToUser) {
            var t = node.text?.toString()?.trim()
            if (t.isNullOrEmpty() && node.childCount == 0) {
                t = node.contentDescription?.toString()?.trim()
            }
            if (!t.isNullOrEmpty()) {
                val r = Rect()
                node.getBoundsInScreen(r)
                if (r.width() > 0 && r.height() > 0) out.add(Item(r, t))
            }
        }
        for (i in 0 until node.childCount) collect(node.getChild(i), out)
    }

    // ---------- لوحة التحديد ----------
    private fun btn(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        setTextColor(Color.WHITE)
        textSize = 15f
        gravity = Gravity.CENTER
        setPadding(dp(8), dp(10), dp(8), dp(10))
        background = GradientDrawable().apply {
            cornerRadius = dp(20).toFloat(); setColor(0xFF1565C0.toInt())
        }
        setOnClickListener { onClick() }
    }

    private fun openPanel() {
        if (panelRoot != null) return
        val list = mutableListOf<Item>()
        collect(rootInActiveWindow, list)
        items = list

        val root = FrameLayout(this)
        root.addView(
            SelectionView(this, list) { updateStatus() },
            FrameLayout.LayoutParams(-1, -1)
        )

        val st = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 14f
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat(); setColor(0xEE212121.toInt())
            }
        }
        status = st
        root.addView(
            st,
            FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
                .apply { topMargin = dp(48) }
        )

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = GradientDrawable().apply {
                cornerRadius = dp(28).toFloat(); setColor(0xEE212121.toInt())
            }
        }
        fun add(b: TextView) {
            bar.addView(b, LinearLayout.LayoutParams(0, -2, 1f).apply {
                setMargins(dp(4), 0, dp(4), 0)
            })
        }
        add(btn("نسخ") { copySelected() })
        add(btn("الكل") { items.forEach { it.selected = true }; root.invalidateAll(); updateStatus() })
        add(btn("صور OCR") { runOcr() })
        add(btn("إغلاق") { closePanel() })
        root.addView(
            bar,
            FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply {
                setMargins(dp(12), 0, dp(12), dp(40))
            }
        )

        val lp = WindowManager.LayoutParams(
            -1, -1,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(root, lp)
        panelRoot = root
        bubble?.visibility = View.GONE
        updateStatus()
    }

    private fun View.invalidateAll() {
        invalidate()
        if (this is FrameLayout) for (i in 0 until childCount) getChildAt(i).invalidate()
    }

    private fun updateStatus() {
        val n = items.count { it.selected }
        status?.text = if (items.isEmpty()) "ما لقيت نص — جرّب زر صور OCR"
        else "محدد $n من ${items.size} — اضغط أو اسحب للتحديد"
    }

    private fun closePanel() {
        panelRoot?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panelRoot = null
        status = null
        busy = false
        bubble?.visibility = View.VISIBLE
    }

    private fun copySelected() {
        val chosen = items.filter { it.selected }
            .sortedWith(compareBy({ it.rect.top }, { it.rect.left }))
        if (chosen.isEmpty()) { toast("حدد نصاً أولاً"); return }
        val text = chosen.joinToString("\n") { it.text }
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("QuickCopy", text))
        toast("تم النسخ ✓")
        closePanel()
    }

    // ---------- OCR للصور ----------
    private fun runOcr() {
        if (busy) return
        busy = true
        status?.text = "جاري التجهيز..."
        Thread {
            val ok = OcrEngine.ensureData(this) { s -> handler.post { status?.text = s } }
            handler.post {
                if (!ok) {
                    status?.text = "تعذر تحميل لغات OCR — تأكد من الإنترنت"
                    busy = false
                } else capture()
            }
        }.start()
    }

    private fun capture() {
        val root = panelRoot ?: run { busy = false; return }
        root.visibility = View.INVISIBLE
        handler.postDelayed({
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(result: ScreenshotResult) {
                    val hb = result.hardwareBuffer
                    val bmp = Bitmap.wrapHardwareBuffer(hb, result.colorSpace)
                        ?.copy(Bitmap.Config.ARGB_8888, false)
                    hb.close()
                    panelRoot?.visibility = View.VISIBLE
                    if (bmp == null) { status?.text = "فشل التقاط الشاشة"; busy = false; return }
                    status?.text = "جاري قراءة الصور..."
                    Thread {
                        val res = try { OcrEngine.recognize(this@CopyService, bmp) } catch (e: Throwable) { emptyList() }
                        handler.post {
                            val add = res.filter { (r, _) -> items.none { Rect.intersects(it.rect, r) } }
                                .map { Item(it.first, it.second) }
                            items.addAll(add)
                            panelRoot?.invalidateAll()
                            updateStatus()
                            if (add.isEmpty()) toast("ما لقيت نص إضافي في الصور")
                            busy = false
                        }
                    }.start()
                }

                override fun onFailure(errorCode: Int) {
                    panelRoot?.visibility = View.VISIBLE
                    status?.text = "تعذر التقاط الشاشة (التطبيق قد يمنع التصوير)"
                    busy = false
                }
            })
        }, 300)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
