package com.example.quickcopy

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

class Item(val rect: Rect, val text: String, var selected: Boolean = false)

class SelectionView(
    ctx: Context,
    private val items: List<Item>,
    private val onChange: () -> Unit
) : View(ctx) {

    private val dim = Paint().apply { color = 0x55000000 }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 3f; color = 0xFF42A5F5.toInt()
    }
    private val fillSel = Paint().apply { color = 0x6643A047 }
    private val strokeSel = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 4f; color = 0xFF2E7D32.toInt()
    }
    private val bandPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 4f; color = Color_WHITE
    }

    private var band: RectF? = null
    private var sx = 0f
    private var sy = 0f
    private var vx = 0f
    private var vy = 0f
    private val off = IntArray(2)

    override fun onDraw(c: Canvas) {
        getLocationOnScreen(off)
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dim)
        c.save()
        c.translate(-off[0].toFloat(), -off[1].toFloat())
        for (i in items) {
            if (i.selected) {
                c.drawRect(i.rect, fillSel)
                c.drawRect(i.rect, strokeSel)
            } else {
                c.drawRect(i.rect, stroke)
            }
        }
        c.restore()
        band?.let { c.drawRect(it, bandPaint) }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                sx = e.rawX; sy = e.rawY; vx = e.x; vy = e.y; band = null
            }
            MotionEvent.ACTION_MOVE -> {
                val d = context.dp(12)
                if (band != null || abs(e.rawX - sx) > d || abs(e.rawY - sy) > d) {
                    band = RectF(min(vx, e.x), min(vy, e.y), max(vx, e.x), max(vy, e.y))
                }
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                if (band == null) {
                    tap(e.rawX.toInt(), e.rawY.toInt())
                } else {
                    val r = Rect(
                        min(sx, e.rawX).toInt(), min(sy, e.rawY).toInt(),
                        max(sx, e.rawX).toInt(), max(sy, e.rawY).toInt()
                    )
                    items.filter { Rect.intersects(it.rect, r) }.forEach { it.selected = true }
                    band = null
                }
                invalidate()
                onChange()
            }
            MotionEvent.ACTION_CANCEL -> { band = null; invalidate() }
        }
        return true
    }

    private fun tap(x: Int, y: Int) {
        items.filter { it.rect.contains(x, y) }
            .minByOrNull { it.rect.width().toLong() * it.rect.height() }
            ?.let { it.selected = !it.selected }
    }

    companion object {
        private const val Color_WHITE = -1
    }
}
