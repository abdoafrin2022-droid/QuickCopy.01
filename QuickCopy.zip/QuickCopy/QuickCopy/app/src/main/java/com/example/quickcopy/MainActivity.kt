package com.example.quickcopy

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(20), dp(40), dp(20), dp(20))
        }
        fun text(s: String, size: Float = 16f, bold: Boolean = false) = TextView(this).apply {
            this.text = s; textSize = size; setTextColor(Color.BLACK)
            textDirection = View.TEXT_DIRECTION_RTL
            gravity = Gravity.START
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(8), 0, dp(8))
        }
        fun button(s: String, onClick: () -> Unit) = Button(this).apply {
            this.text = s; setOnClickListener { onClick() }
        }

        root.addView(text("نسخ سريع", 26f, true))
        root.addView(text(
            "1) اضغط الزر الأول وفعّل «نسخ سريع» من إعدادات إمكانية الوصول.\n" +
            "2) إذا أندرويد منع التفعيل (إعدادات مقيّدة): اضغط الزر الثاني، ثم النقاط الثلاث ⋮ ثم «السماح بالإعدادات المقيّدة»، ثم ارجع للخطوة 1.\n" +
            "3) اضغط الزر الثالث لتحميل لغات قراءة الصور (مرة واحدة فقط).\n" +
            "4) افتح أي تطبيق، اضغط الزر العائم 📋، ثم اضغط أو اسحب على النص، ثم «نسخ»."
        ))
        root.addView(button("1) فتح إعدادات إمكانية الوصول") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(button("2) معلومات التطبيق (للسماح بالإعدادات المقيّدة)") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })
        val status = text(if (OcrEngine.hasData(this)) "لغات OCR جاهزة ✓" else "لغات OCR غير محمّلة بعد")
        root.addView(button("3) تحميل لغات قراءة الصور (عربي + إنجليزي)") {
            val h = Handler(Looper.getMainLooper())
            Thread {
                val ok = OcrEngine.ensureData(this) { s -> h.post { status.text = s } }
                h.post { status.text = if (ok) "لغات OCR جاهزة ✓" else "فشل التحميل — تأكد من الإنترنت" }
            }.start()
        })
        root.addView(status)
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
